# QMS Backend

NestJS backend for the Queue Management System — auth/RBAC, queue configuration,
the realtime queue engine (ETA estimation that learns from actual service times),
and Socket.io realtime events. Matches `qms-database-schema.sql` and
`qms-api-contract.md` from the earlier design pass.

## Architecture (Clean Architecture mapping)

```
src/
  auth/            — registration, login, JWT issuance/rotation, guest sessions
  users/           — profile + preferences (language, dark mode)
  organizations/   — tenant root, white-label branding
  branches/        — branches within an organization
  queues/
    queues.service.ts        — config, pause/resume, QR tokens, employee assignment
    queue-engine.service.ts  — ETA calculation, "smart queue optimization"
  tickets/         — full ticket lifecycle: join, cancel, rate, call-next,
                     recall, complete, skip, transfer, priority
  realtime/        — Socket.io gateway, one source of truth for live events
  common/          — guards (JWT, roles), decorators, global filters/interceptors
  prisma/          — PrismaService/PrismaModule wrapping the generated client
```

Controllers only translate HTTP → service calls. Services hold business rules
and are what you'd unit test. Prisma is the only layer that knows about SQL —
swapping it later (e.g. for a different ORM) wouldn't touch controllers or
the queue engine's logic.

## Setup

```bash
npm install
cp .env.example .env   # fill in DATABASE_URL and JWT_ACCESS_SECRET
npx prisma migrate dev --name init
npm run start:dev
```

## What's implemented vs. left as next steps

Implemented: auth (register/login/refresh/guest), RBAC guards, org/branch
CRUD with scope checks, queue config + QR token issuance/resolution, full
ticket lifecycle, ETA engine with a learning average, Socket.io broadcasts
for every state change, audit log interceptor, rate limiting on login/join,
notification dispatch (15/10/5-min ETA thresholds, next-up, called,
cancelled, skipped, queue paused/resumed) logged to the `notifications`
table and sent through pluggable provider stubs, a scheduled job that
auto-skips no-shows past `noShowTimeoutSeconds`, and branch reports
(daily/weekly/monthly/yearly) as JSON, PDF, or Excel.

Not yet implemented (flagged so nothing is assumed silently):
- Real push/SMS/email delivery — `src/notifications/providers/*.ts` are
  stubs that log to the console. Swap in Firebase Cloud Messaging, Twilio,
  and SendGrid/SES respectively; the dispatch logic and dedupe/logging
  around them is already in place.
- Automated tests.
- File storage for generated reports — PDF/Excel reports are streamed back
  as a direct download rather than uploaded to S3/GCS with a signed URL;
  swap that in if you want reports to persist beyond the request.

## New in this pass

```
src/notifications/
  notifications.service.ts   — dispatch + dedupe + logging, one place all
                                event messages are defined
  providers/                 — push/sms/email stubs, swap for real providers
src/scheduler/
  scheduler.service.ts        — @Cron jobs: no-show auto-skip, ETA threshold
                                notifications (every 30s)
src/reports/
  reports.service.ts           — aggregates tickets into a period report,
                                renders PDF (pdfkit) and Excel (exceljs)
  reports.controller.ts        — GET /branches/:id/reports?period=&format=
```

`User.pushToken` was added to the schema (both `prisma/schema.prisma` and
the standalone `qms-database-schema.sql`) so notifications have somewhere
to deliver to — remember to re-run `prisma migrate dev` if you already
migrated against the earlier schema.
