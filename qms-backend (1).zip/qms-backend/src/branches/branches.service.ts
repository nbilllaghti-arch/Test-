import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';

@Injectable()
export class BranchesService {
  constructor(private prisma: PrismaService) {}

  async create(organizationId: string, requester: AuthenticatedUser, data: { name: string; address?: string; timezone?: string }) {
    this.assertOrgAccess(requester, organizationId);
    return this.prisma.branch.create({ data: { organizationId, ...data } });
  }

  async listForOrg(organizationId: string, requester: AuthenticatedUser) {
    this.assertOrgAccess(requester, organizationId);
    return this.prisma.branch.findMany({ where: { organizationId } });
  }

  async getById(id: string, requester: AuthenticatedUser) {
    const branch = await this.prisma.branch.findUnique({ where: { id } });
    if (!branch) throw new NotFoundException('Branch not found');
    this.assertBranchAccess(requester, branch.organizationId, branch.id);
    return branch;
  }

  async update(id: string, requester: AuthenticatedUser, data: { name?: string; address?: string; timezone?: string; isActive?: boolean }) {
    const branch = await this.prisma.branch.findUnique({ where: { id } });
    if (!branch) throw new NotFoundException('Branch not found');
    this.assertBranchAccess(requester, branch.organizationId, branch.id);
    return this.prisma.branch.update({ where: { id }, data });
  }

  private assertOrgAccess(requester: AuthenticatedUser, organizationId: string) {
    if (requester.role === 'super_admin') return;
    if (requester.role === 'org_admin' && requester.organizationId === organizationId) return;
    throw new ForbiddenException('You do not have access to this organization');
  }

  private assertBranchAccess(requester: AuthenticatedUser, organizationId: string, branchId: string) {
    if (requester.role === 'super_admin') return;
    if (requester.role === 'org_admin' && requester.organizationId === organizationId) return;
    if (requester.role === 'branch_admin' && requester.branchId === branchId) return;
    throw new ForbiddenException('You do not have access to this branch');
  }
}
