import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { BranchesService } from './branches.service';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller()
export class BranchesController {
  constructor(private branchesService: BranchesService) {}

  @Roles('super_admin', 'org_admin')
  @Post('organizations/:orgId/branches')
  create(
    @Param('orgId') orgId: string,
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: { name: string; address?: string; timezone?: string },
  ) {
    return this.branchesService.create(orgId, user, body);
  }

  @Roles('super_admin', 'org_admin', 'branch_admin')
  @Get('organizations/:orgId/branches')
  list(@Param('orgId') orgId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.branchesService.listForOrg(orgId, user);
  }

  @Roles('super_admin', 'org_admin', 'branch_admin')
  @Get('branches/:id')
  getOne(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.branchesService.getById(id, user);
  }

  @Roles('super_admin', 'org_admin', 'branch_admin')
  @Patch('branches/:id')
  update(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: { name?: string; address?: string; timezone?: string; isActive?: boolean },
  ) {
    return this.branchesService.update(id, user, body);
  }
}
