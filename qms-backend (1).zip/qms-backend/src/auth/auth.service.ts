import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { LoginDto, RegisterDto } from './dto/auth.dto';

const ACCESS_TOKEN_TTL = '15m';
const REFRESH_TOKEN_TTL_DAYS = 30;

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
    private config: ConfigService,
  ) {}

  async register(dto: RegisterDto) {
    const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existing) throw new ConflictException('An account with this email already exists');

    const passwordHash = await bcrypt.hash(dto.password, 12);

    const organizationId =
      dto.role === 'org_admin'
        ? (await this.prisma.organization.create({ data: { name: dto.organizationName ?? `${dto.fullName}'s organization` } })).id
        : null;

    const user = await this.prisma.user.create({
      data: {
        role: dto.role,
        fullName: dto.fullName,
        email: dto.email,
        passwordHash,
        organizationId,
      },
    });

    return this.issueTokens(user.id, user.role, user.organizationId, null);
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (!user || !user.passwordHash) throw new UnauthorizedException('Invalid credentials');

    const valid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!valid) throw new UnauthorizedException('Invalid credentials');

    await this.prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    return this.issueTokens(user.id, user.role, user.organizationId, user.branchId);
  }

  async refresh(refreshToken: string) {
    const tokenHash = this.hashToken(refreshToken);
    const stored = await this.prisma.refreshToken.findFirst({
      where: { tokenHash, revoked: false, expiresAt: { gt: new Date() } },
      include: { user: true },
    });
    if (!stored) throw new UnauthorizedException('Refresh token invalid or expired');

    // Rotate: revoke the old one, issue a new pair.
    await this.prisma.refreshToken.update({ where: { id: stored.id }, data: { revoked: true } });

    return this.issueTokens(stored.user.id, stored.user.role, stored.user.organizationId, stored.user.branchId);
  }

  /**
   * Guest customers get a short-lived session without a password —
   * used only for joining a queue and checking ticket status.
   */
  async createGuestSession() {
    const guest = await this.prisma.user.create({
      data: { role: 'customer', isGuest: true },
    });
    const accessToken = this.jwt.sign(
      { sub: guest.id, role: guest.role, organizationId: null, branchId: null },
      { expiresIn: '2h' },
    );
    return { userId: guest.id, accessToken };
  }

  private async issueTokens(userId: string, role: string, organizationId: string | null, branchId: string | null) {
    const accessToken = this.jwt.sign(
      { sub: userId, role, organizationId, branchId },
      { expiresIn: ACCESS_TOKEN_TTL },
    );

    const refreshTokenRaw = crypto.randomBytes(48).toString('hex');
    const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000);
    await this.prisma.refreshToken.create({
      data: { userId, tokenHash: this.hashToken(refreshTokenRaw), expiresAt },
    });

    return { accessToken, refreshToken: refreshTokenRaw, role };
  }

  private hashToken(raw: string) {
    return crypto.createHash('sha256').update(raw).digest('hex');
  }
}
