import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { RealtimeGateway } from '../realtime/realtime.gateway';
import { NotificationsService } from '../notifications/notifications.service';

const LEARNING_SAMPLE_SIZE = 20; // rolling window of recent completed tickets used to refine the estimate

@Injectable()
export class QueueEngineService {
  constructor(
    private prisma: PrismaService,
    private realtime: RealtimeGateway,
    private notifications: NotificationsService,
  ) {}

  /**
   * Effective average service time for a queue: blends the configured
   * default with the real average of the most recent completed tickets,
   * so the estimate improves as actual data accumulates ("learns from
   * actual service durations").
   */
  async effectiveAvgServiceSeconds(queueId: string): Promise<number> {
    const queue = await this.prisma.queue.findUniqueOrThrow({ where: { id: queueId } });
    const recentSamples = await this.prisma.serviceSample.findMany({
      where: { queueId },
      orderBy: { recordedAt: 'desc' },
      take: LEARNING_SAMPLE_SIZE,
    });

    if (recentSamples.length === 0) return queue.avgServiceSeconds;

    const learnedAvg =
      recentSamples.reduce((sum, s) => sum + s.durationSeconds, 0) / recentSamples.length;

    // Weight configured default 30% / learned average 70% once we have enough data,
    // so a couple of outlier tickets can't swing the estimate wildly.
    return Math.round(queue.avgServiceSeconds * 0.3 + learnedAvg * 0.7);
  }

  async activeEmployeeCount(queueId: string): Promise<number> {
    const count = await this.prisma.queueEmployee.count({ where: { queueId } });
    return Math.max(count, 1); // never divide by zero
  }

  /** Position among *waiting* tickets, priority tickets counted first. */
  async positionOf(queueId: string, ticketId: string): Promise<number> {
    const waiting = await this.prisma.ticket.findMany({
      where: { queueId, status: 'waiting' },
      orderBy: [{ isPriority: 'desc' }, { joinedAt: 'asc' }],
      select: { id: true },
    });
    const idx = waiting.findIndex((t) => t.id === ticketId);
    return idx === -1 ? waiting.length : idx;
  }

  async estimateWaitSeconds(queueId: string, ticketId: string): Promise<number> {
    const [avg, employees, position] = await Promise.all([
      this.effectiveAvgServiceSeconds(queueId),
      this.activeEmployeeCount(queueId),
      this.positionOf(queueId, ticketId),
    ]);
    return Math.max(0, Math.ceil(position / employees) * avg);
  }

  /**
   * Recomputes ETA for every waiting ticket in a queue and broadcasts any
   * that changed meaningfully (>60s difference) — called after events that
   * shift positions: cancellations, skips, completions, pause/resume.
   */
  async recalculateAndBroadcast(queueId: string, reason: string) {
    const waiting = await this.prisma.ticket.findMany({
      where: { queueId, status: 'waiting' },
      orderBy: [{ isPriority: 'desc' }, { joinedAt: 'asc' }],
    });

    const avg = await this.effectiveAvgServiceSeconds(queueId);
    const employees = await this.activeEmployeeCount(queueId);

    for (let i = 0; i < waiting.length; i++) {
      const newEstimate = Math.max(0, Math.ceil(i / employees) * avg);
      const ticket = waiting[i];
      const changed = ticket.estimatedWaitSeconds === null || Math.abs(ticket.estimatedWaitSeconds - newEstimate) >= 60;

      await this.prisma.ticket.update({ where: { id: ticket.id }, data: { estimatedWaitSeconds: newEstimate } });

      if (changed) {
        this.realtime.emitTicketEtaChanged(queueId, {
          ticketId: ticket.id,
          estimatedWaitSeconds: newEstimate,
          reason,
        });
      }

      if (i === 0 && !(await this.notifications.hasBeenNotified(ticket.id, 'next_up'))) {
        await this.notifications.notify(ticket.id, 'next_up');
      }
    }
  }
}
