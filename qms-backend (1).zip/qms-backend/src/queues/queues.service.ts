import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { RealtimeGateway } from '../realtime/realtime.gateway';
import { NotificationsService } from '../notifications/notifications.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { CreateQueueDto, UpdateQueueDto } from './dto/queue.dto';

@Injectable()
export class QueuesService {
  constructor(
    private prisma: PrismaService,
    private realtime: RealtimeGateway,
    private notifications: NotificationsService,
  ) {}

  async create(branchId: string, requester: AuthenticatedUser, dto: CreateQueueDto) {
    await this.assertBranchAccess(requester, branchId);
    return this.prisma.queue.create({ data: { branchId, ...dto } });
  }

  async listForBranch(branchId: string) {
    const queues = await this.prisma.queue.findMany({ where: { branchId } });
    return Promise.all(queues.map((q) => this.findLiveStatus(q.id)));
  }

  async findLiveStatus(id: string) {
    const queue = await this.prisma.queue.findUnique({ where: { id } });
    if (!queue) throw new NotFoundException('Queue not found');

    const [servingTicket, waitingCount, servedToday] = await Promise.all([
      this.prisma.ticket.findFirst({ where: { queueId: id, status: 'serving' }, orderBy: { calledAt: 'desc' } }),
      this.prisma.ticket.count({ where: { queueId: id, status: 'waiting' } }),
      this.prisma.ticket.count({
        where: { queueId: id, status: 'done', completedAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } },
      }),
    ]);

    return {
      ...queue,
      nowServing: servingTicket?.ticketNumber ?? 0,
      waitingCount,
      servedToday,
    };
  }

  async update(id: string, requester: AuthenticatedUser, dto: UpdateQueueDto) {
    const queue = await this.getOr404(id);
    await this.assertBranchAccess(requester, queue.branchId);
    return this.prisma.queue.update({ where: { id }, data: dto });
  }

  async assignEmployee(queueId: string, requester: AuthenticatedUser, userId: string) {
    const queue = await this.getOr404(queueId);
    await this.assertBranchAccess(requester, queue.branchId);
    return this.prisma.queueEmployee.upsert({
      where: { queueId_userId: { queueId, userId } },
      create: { queueId, userId },
      update: {},
    });
  }

  async generateQrToken(queueId: string, requester: AuthenticatedUser) {
    const queue = await this.getOr404(queueId);
    await this.assertBranchAccess(requester, queue.branchId);
    const token = crypto.randomBytes(24).toString('base64url');
    const qrToken = await this.prisma.qrToken.create({ data: { queueId, token } });
    // In production: generate an actual QR image (e.g. via `qrcode` package) encoding
    // only `token` as an opaque string, and upload it to object storage.
    return { token: qrToken.token, qrPayload: `qms://join/${qrToken.token}` };
  }

  async resolveQrToken(token: string) {
    const qrToken = await this.prisma.qrToken.findUnique({ where: { token } });
    if (!qrToken || (qrToken.expiresAt && qrToken.expiresAt < new Date())) {
      throw new NotFoundException('This QR code is invalid or has expired');
    }
    return this.findLiveStatus(qrToken.queueId);
  }

  async setPaused(queueId: string, requester: AuthenticatedUser, paused: boolean) {
    const queue = await this.getOr404(queueId);
    await this.assertBranchAccess(requester, queue.branchId);
    const updated = await this.prisma.queue.update({ where: { id: queueId }, data: { isPaused: paused } });
    this.realtime.emitQueuePauseState(queueId, paused);

    const waiting = await this.prisma.ticket.findMany({ where: { queueId, status: 'waiting' }, select: { id: true } });
    await Promise.all(waiting.map((t) => this.notifications.notify(t.id, paused ? 'queue_paused' : 'queue_resumed')));

    return updated;
  }

  private async getOr404(id: string) {
    const queue = await this.prisma.queue.findUnique({ where: { id } });
    if (!queue) throw new NotFoundException('Queue not found');
    return queue;
  }

  private async assertBranchAccess(requester: AuthenticatedUser, branchId: string) {
    if (requester.role === 'super_admin' || requester.role === 'org_admin') return; // org-level scope checked upstream
    if (['branch_admin', 'reception', 'employee'].includes(requester.role) && requester.branchId === branchId) return;
    throw new ForbiddenException('You do not have access to this branch');
  }
}
