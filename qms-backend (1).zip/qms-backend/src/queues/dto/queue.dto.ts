import { IsBoolean, IsIn, IsInt, IsOptional, IsString, Min } from 'class-validator';

export class CreateQueueDto {
  @IsString()
  name: string;

  @IsString()
  code: string;

  @IsOptional()
  @IsIn(['remote', 'qr', 'both'])
  joinMode?: 'remote' | 'qr' | 'both';

  @IsOptional()
  @IsInt()
  @Min(30)
  avgServiceSeconds?: number;

  @IsOptional()
  @IsInt()
  @Min(30)
  noShowTimeoutSeconds?: number;
}

export class UpdateQueueDto {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsIn(['remote', 'qr', 'both'])
  joinMode?: 'remote' | 'qr' | 'both';

  @IsOptional()
  @IsInt()
  @Min(30)
  avgServiceSeconds?: number;

  @IsOptional()
  @IsInt()
  @Min(30)
  noShowTimeoutSeconds?: number;

  @IsOptional()
  @IsBoolean()
  priorityEnabled?: boolean;
}
