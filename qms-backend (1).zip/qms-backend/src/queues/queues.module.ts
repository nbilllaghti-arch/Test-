import { Module } from '@nestjs/common';
import { QueuesService } from './queues.service';
import { QueuesController } from './queues.controller';
import { QueueEngineService } from './queue-engine.service';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [NotificationsModule],
  providers: [QueuesService, QueueEngineService],
  controllers: [QueuesController],
  exports: [QueuesService, QueueEngineService],
})
export class QueuesModule {}
