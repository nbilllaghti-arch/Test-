import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { QueuesService } from './queues.service';
import { CreateQueueDto, UpdateQueueDto } from './dto/queue.dto';

@Controller()
export class QueuesController {
  constructor(private queuesService: QueuesService) {}

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin')
  @Post('branches/:branchId/queues')
  create(
    @Param('branchId') branchId: string,
    @CurrentUser() user: AuthenticatedUser,
    @Body() dto: CreateQueueDto,
  ) {
    return this.queuesService.create(branchId, user, dto);
  }

  // Public — used by the customer join page to browse a branch's queues.
  @Get('branches/:branchId/queues')
  listForBranch(@Param('branchId') branchId: string) {
    return this.queuesService.listForBranch(branchId);
  }

  // Public — lets the customer join flow browse available queues for a branch.
  @Get('branches/:branchId/queues')
  listForBranch(@Param('branchId') branchId: string) {
    return this.queuesService.listForBranch(branchId);
  }

  // Public — used by the display screen and by customers checking a queue before joining.
  @Get('queues/:id')
  liveStatus(@Param('id') id: string) {
    return this.queuesService.findLiveStatus(id);
  }

  @Get('queues/:id/display')
  displayScreen(@Param('id') id: string) {
    return this.queuesService.findLiveStatus(id);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin')
  @Patch('queues/:id')
  update(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser, @Body() dto: UpdateQueueDto) {
    return this.queuesService.update(id, user, dto);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin')
  @Post('queues/:id/employees')
  assignEmployee(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser, @Body('userId') userId: string) {
    return this.queuesService.assignEmployee(id, user, userId);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin')
  @Post('queues/:id/qr-token')
  generateQr(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.queuesService.generateQrToken(id, user);
  }

  // Public — scanning the QR calls this to resolve the opaque token server-side.
  @Post('qr/:token/resolve')
  resolveQr(@Param('token') token: string) {
    return this.queuesService.resolveQrToken(token);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception')
  @Post('queues/:id/pause')
  pause(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.queuesService.setPaused(id, user, true);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception')
  @Post('queues/:id/resume')
  resume(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.queuesService.setPaused(id, user, false);
  }
}
