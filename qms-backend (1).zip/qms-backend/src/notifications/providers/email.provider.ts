import { NotificationProvider } from './push.provider';

/**
 * Stub implementation. Replace with a real SendGrid/SES call.
 */
export class EmailProvider implements NotificationProvider {
  async send(to: string, title: string, body: string): Promise<void> {
    // eslint-disable-next-line no-console
    console.log(`[email -> ${to}] ${title}: ${body}`);
  }
}
