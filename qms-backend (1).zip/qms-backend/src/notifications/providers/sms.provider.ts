import { NotificationProvider } from './push.provider';

/**
 * Stub implementation. Replace with a real Twilio call:
 *   twilioClient.messages.create({ to, from: TWILIO_NUMBER, body })
 */
export class SmsProvider implements NotificationProvider {
  async send(to: string, _title: string, body: string): Promise<void> {
    // eslint-disable-next-line no-console
    console.log(`[sms -> ${to}] ${body}`);
  }
}
