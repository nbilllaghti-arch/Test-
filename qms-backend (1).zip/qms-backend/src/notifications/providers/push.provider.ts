export interface NotificationProvider {
  send(to: string, title: string, body: string): Promise<void>;
}

/**
 * Stub implementation. Replace with a real Firebase Cloud Messaging call:
 *   admin.messaging().send({ token: to, notification: { title, body } })
 * `to` here would be the customer's stored device/push token.
 */
export class PushProvider implements NotificationProvider {
  async send(to: string, title: string, body: string): Promise<void> {
    // eslint-disable-next-line no-console
    console.log(`[push -> ${to}] ${title}: ${body}`);
  }
}
