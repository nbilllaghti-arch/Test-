import { Injectable } from '@nestjs/common';
import { NotificationChannel } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { PushProvider } from './providers/push.provider';
import { SmsProvider } from './providers/sms.provider';
import { EmailProvider } from './providers/email.provider';

const MESSAGES: Record<string, { title: string; body: string }> = {
  eta_15_min: { title: 'Almost there', body: 'About 15 minutes left until your turn.' },
  eta_10_min: { title: 'Almost there', body: 'About 10 minutes left until your turn.' },
  eta_5_min: { title: 'Get ready', body: 'About 5 minutes left until your turn.' },
  next_up: { title: "You're next", body: 'Please be ready — you are next in line.' },
  called: { title: 'Your turn', body: 'It is your turn now, please proceed.' },
  cancelled: { title: 'Reservation cancelled', body: 'Your ticket has been cancelled.' },
  skipped: { title: 'You were skipped', body: 'You were skipped after not appearing in time. You can rejoin the queue.' },
  queue_paused: { title: 'Queue paused', body: 'This queue has been paused temporarily by staff.' },
  queue_resumed: { title: 'Queue resumed', body: 'This queue is now moving again.' },
};

@Injectable()
export class NotificationsService {
  private push = new PushProvider();
  private sms = new SmsProvider();
  private email = new EmailProvider();

  constructor(private prisma: PrismaService) {}

  /** True if this exact event has already been sent for this ticket (used to dedupe ETA thresholds). */
  async hasBeenNotified(ticketId: string, eventType: string): Promise<boolean> {
    const existing = await this.prisma.notification.findFirst({ where: { ticketId, eventType } });
    return !!existing;
  }

  async notify(ticketId: string, eventType: keyof typeof MESSAGES): Promise<void> {
    const ticket = await this.prisma.ticket.findUnique({
      where: { id: ticketId },
      include: { customer: true },
    });
    if (!ticket) return;

    const template = MESSAGES[eventType];
    const customer = ticket.customer;

    const { channel, destination } = this.pickChannel(customer);

    await this.prisma.notification.create({
      data: { ticketId, channel, eventType, payload: { title: template.title, body: template.body } },
    });

    if (!destination) return; // guest with no contact info on file — logged only

    const provider = channel === 'push' ? this.push : channel === 'sms' ? this.sms : this.email;
    await provider.send(destination, template.title, template.body);
  }

  private pickChannel(customer: { pushToken?: string | null; email?: string | null; phone?: string | null } | null): {
    channel: NotificationChannel;
    destination: string | null;
  } {
    if (customer?.pushToken) return { channel: 'push', destination: customer.pushToken };
    if (customer?.phone) return { channel: 'sms', destination: customer.phone };
    if (customer?.email) return { channel: 'email', destination: customer.email };
    return { channel: 'push', destination: null };
  }
}
