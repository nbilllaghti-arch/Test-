import { ForbiddenException, Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async findById(id: string) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException('User not found');
    const { passwordHash: _omit, ...safe } = user;
    return safe;
  }

  async updatePreferences(id: string, data: { language?: string; darkMode?: boolean }) {
    return this.prisma.user.update({ where: { id }, data });
  }

  async createStaff(
    organizationId: string,
    requester: AuthenticatedUser,
    data: {
      role: 'branch_admin' | 'employee' | 'reception';
      fullName: string;
      email: string;
      password: string;
      branchId?: string;
    },
  ) {
    this.assertOrgAccess(requester, organizationId);

    const existing = await this.prisma.user.findUnique({ where: { email: data.email } });
    if (existing) throw new ConflictException('An account with this email already exists');

    const passwordHash = await bcrypt.hash(data.password, 12);
    const { passwordHash: _omit, ...safe } = await this.prisma.user.create({
      data: {
        organizationId,
        branchId: data.branchId,
        role: data.role,
        fullName: data.fullName,
        email: data.email,
        passwordHash,
      },
    });
    return safe;
  }

  async listStaff(organizationId: string, requester: AuthenticatedUser) {
    this.assertOrgAccess(requester, organizationId);
    const users = await this.prisma.user.findMany({
      where: { organizationId, role: { in: ['branch_admin', 'employee', 'reception'] } },
      orderBy: { createdAt: 'desc' },
    });
    return users.map(({ passwordHash: _omit, ...safe }) => safe);
  }

  private assertOrgAccess(requester: AuthenticatedUser, organizationId: string) {
    if (requester.role === 'super_admin') return;
    if (requester.role === 'org_admin' && requester.organizationId === organizationId) return;
    throw new ForbiddenException('You do not have access to manage staff for this organization');
  }
}
