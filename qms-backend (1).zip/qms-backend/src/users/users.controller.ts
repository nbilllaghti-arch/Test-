import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { UsersService } from './users.service';

@UseGuards(JwtAuthGuard)
@Controller('users')
export class UsersController {
  constructor(private usersService: UsersService) {}

  @Get('me')
  me(@CurrentUser() user: AuthenticatedUser) {
    return this.usersService.findById(user.id);
  }

  @Patch('me/preferences')
  updatePreferences(
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: { language?: string; darkMode?: boolean },
  ) {
    return this.usersService.updatePreferences(user.id, body);
  }
}

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('organizations/:orgId/staff')
export class StaffController {
  constructor(private usersService: UsersService) {}

  @Roles('super_admin', 'org_admin')
  @Get()
  list(@Param('orgId') orgId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.usersService.listStaff(orgId, user);
  }

  @Roles('super_admin', 'org_admin')
  @Post()
  create(
    @Param('orgId') orgId: string,
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: { role: 'branch_admin' | 'employee' | 'reception'; fullName: string; email: string; password: string; branchId?: string },
  ) {
    return this.usersService.createStaff(orgId, user, body);
  }
}
