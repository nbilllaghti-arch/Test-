import { Controller, Get, Param, Query, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { ReportsService } from './reports.service';
import { ReportQueryDto } from './dto/report-query.dto';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('super_admin', 'org_admin', 'branch_admin')
@Controller('branches/:branchId/reports')
export class ReportsController {
  constructor(private reportsService: ReportsService) {}

  @Get()
  async report(
    @Param('branchId') branchId: string,
    @CurrentUser() user: AuthenticatedUser,
    @Query() query: ReportQueryDto,
    @Res() res: Response,
  ) {
    const data = await this.reportsService.generate(branchId, user, query.period);
    const filenameBase = `${data.branchName.replace(/\s+/g, '-').toLowerCase()}-${data.period}-report`;

    if (query.format === 'json') {
      res.json(data);
      return;
    }

    if (query.format === 'pdf') {
      const buffer = await this.reportsService.generatePdfBuffer(data);
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filenameBase}.pdf"`,
      });
      res.send(buffer);
      return;
    }

    // format === 'excel'
    const buffer = await this.reportsService.generateExcelBuffer(data);
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="${filenameBase}.xlsx"`,
    });
    res.send(buffer);
  }
}
