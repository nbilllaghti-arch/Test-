import { ForbiddenException, Injectable } from '@nestjs/common';
import PDFDocument from 'pdfkit';
import * as ExcelJS from 'exceljs';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { ReportPeriod } from './dto/report-query.dto';

interface ReportData {
  branchName: string;
  period: ReportPeriod;
  rangeStart: Date;
  rangeEnd: Date;
  totalTickets: number;
  servedCount: number;
  cancelledCount: number;
  skippedCount: number;
  cancellationRate: number;
  noShowRate: number;
  avgWaitSeconds: number;
  avgServiceSeconds: number;
  peakHours: Array<{ hour: number; count: number }>;
  employeePerformance: Array<{ employeeName: string; served: number; avgServiceSeconds: number }>;
}

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  async generate(branchId: string, requester: AuthenticatedUser, period: ReportPeriod) {
    const branch = await this.prisma.branch.findUniqueOrThrow({ where: { id: branchId } });
    this.assertAccess(requester, branch.organizationId, branchId);

    const { start, end } = this.rangeFor(period);

    const tickets = await this.prisma.ticket.findMany({
      where: { queue: { branchId }, joinedAt: { gte: start, lt: end } },
      include: { servedByUser: true },
    });

    const served = tickets.filter((t) => t.status === 'done');
    const cancelled = tickets.filter((t) => t.status === 'cancelled');
    const skipped = tickets.filter((t) => t.status === 'skipped');

    const waitDurations = served
      .filter((t) => t.calledAt)
      .map((t) => (t.calledAt!.getTime() - t.joinedAt.getTime()) / 1000);
    const serviceDurations = served
      .filter((t) => t.calledAt && t.completedAt)
      .map((t) => (t.completedAt!.getTime() - t.calledAt!.getTime()) / 1000);

    const hourCounts = new Map<number, number>();
    for (const t of tickets) {
      const hour = t.joinedAt.getHours();
      hourCounts.set(hour, (hourCounts.get(hour) ?? 0) + 1);
    }
    const peakHours = [...hourCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([hour, count]) => ({ hour, count }));

    const employeeMap = new Map<string, { name: string; served: number; totalDuration: number }>();
    for (const t of served) {
      if (!t.servedBy || !t.calledAt || !t.completedAt) continue;
      const key = t.servedBy;
      const existing = employeeMap.get(key) ?? { name: t.servedByUser?.fullName ?? 'Unknown', served: 0, totalDuration: 0 };
      existing.served += 1;
      existing.totalDuration += (t.completedAt.getTime() - t.calledAt.getTime()) / 1000;
      employeeMap.set(key, existing);
    }

    const data: ReportData = {
      branchName: branch.name,
      period,
      rangeStart: start,
      rangeEnd: end,
      totalTickets: tickets.length,
      servedCount: served.length,
      cancelledCount: cancelled.length,
      skippedCount: skipped.length,
      cancellationRate: tickets.length ? cancelled.length / tickets.length : 0,
      noShowRate: tickets.length ? skipped.length / tickets.length : 0,
      avgWaitSeconds: average(waitDurations),
      avgServiceSeconds: average(serviceDurations),
      peakHours,
      employeePerformance: [...employeeMap.values()].map((e) => ({
        employeeName: e.name,
        served: e.served,
        avgServiceSeconds: Math.round(e.totalDuration / e.served),
      })),
    };

    return data;
  }

  async generatePdfBuffer(data: ReportData): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ margin: 50 });
      const chunks: Buffer[] = [];
      doc.on('data', (chunk) => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      doc.fontSize(18).text(`${data.branchName} — ${data.period} report`, { align: 'left' });
      doc.fontSize(10).fillColor('gray').text(`${data.rangeStart.toDateString()} – ${data.rangeEnd.toDateString()}`);
      doc.moveDown();

      doc.fillColor('black').fontSize(12);
      const rows: Array<[string, string]> = [
        ['Total tickets', String(data.totalTickets)],
        ['Served', String(data.servedCount)],
        ['Cancelled', String(data.cancelledCount)],
        ['Skipped (no-show)', String(data.skippedCount)],
        ['Cancellation rate', `${(data.cancellationRate * 100).toFixed(1)}%`],
        ['No-show rate', `${(data.noShowRate * 100).toFixed(1)}%`],
        ['Avg. wait time', formatDuration(data.avgWaitSeconds)],
        ['Avg. service time', formatDuration(data.avgServiceSeconds)],
      ];
      for (const [label, value] of rows) {
        doc.text(`${label}: ${value}`);
      }

      doc.moveDown();
      doc.fontSize(13).text('Peak hours', { underline: true });
      doc.fontSize(12);
      for (const p of data.peakHours) {
        doc.text(`${String(p.hour).padStart(2, '0')}:00 — ${p.count} tickets`);
      }

      doc.moveDown();
      doc.fontSize(13).text('Employee performance', { underline: true });
      doc.fontSize(12);
      for (const e of data.employeePerformance) {
        doc.text(`${e.employeeName}: ${e.served} served, avg ${formatDuration(e.avgServiceSeconds)}`);
      }

      doc.end();
    });
  }

  async generateExcelBuffer(data: ReportData): Promise<Buffer> {
    const workbook = new ExcelJS.Workbook();

    const summary = workbook.addWorksheet('Summary');
    summary.columns = [{ header: 'Metric', key: 'metric', width: 28 }, { header: 'Value', key: 'value', width: 20 }];
    summary.addRows([
      { metric: 'Branch', value: data.branchName },
      { metric: 'Period', value: data.period },
      { metric: 'Range', value: `${data.rangeStart.toDateString()} – ${data.rangeEnd.toDateString()}` },
      { metric: 'Total tickets', value: data.totalTickets },
      { metric: 'Served', value: data.servedCount },
      { metric: 'Cancelled', value: data.cancelledCount },
      { metric: 'Skipped (no-show)', value: data.skippedCount },
      { metric: 'Cancellation rate', value: `${(data.cancellationRate * 100).toFixed(1)}%` },
      { metric: 'No-show rate', value: `${(data.noShowRate * 100).toFixed(1)}%` },
      { metric: 'Avg. wait time', value: formatDuration(data.avgWaitSeconds) },
      { metric: 'Avg. service time', value: formatDuration(data.avgServiceSeconds) },
    ]);

    const peak = workbook.addWorksheet('Peak Hours');
    peak.columns = [{ header: 'Hour', key: 'hour', width: 10 }, { header: 'Tickets', key: 'count', width: 12 }];
    peak.addRows(data.peakHours.map((p) => ({ hour: `${String(p.hour).padStart(2, '0')}:00`, count: p.count })));

    const employees = workbook.addWorksheet('Employee Performance');
    employees.columns = [
      { header: 'Employee', key: 'name', width: 24 },
      { header: 'Served', key: 'served', width: 12 },
      { header: 'Avg. service time', key: 'avg', width: 20 },
    ];
    employees.addRows(
      data.employeePerformance.map((e) => ({ name: e.employeeName, served: e.served, avg: formatDuration(e.avgServiceSeconds) })),
    );

    return workbook.xlsx.writeBuffer() as unknown as Buffer;
  }

  private rangeFor(period: ReportPeriod): { start: Date; end: Date } {
    const now = new Date();
    const end = now;
    let start: Date;
    switch (period) {
      case 'daily':
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'weekly':
        start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'monthly':
        start = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'yearly':
        start = new Date(now.getFullYear(), 0, 1);
        break;
    }
    return { start, end };
  }

  private assertAccess(requester: AuthenticatedUser, organizationId: string, branchId: string) {
    if (requester.role === 'super_admin') return;
    if (requester.role === 'org_admin' && requester.organizationId === organizationId) return;
    if (requester.role === 'branch_admin' && requester.branchId === branchId) return;
    throw new ForbiddenException('You do not have access to reports for this branch');
  }
}

function average(values: number[]): number {
  if (values.length === 0) return 0;
  return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}m ${s}s`;
}
