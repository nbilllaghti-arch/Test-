import { IsIn } from 'class-validator';

export type ReportPeriod = 'daily' | 'weekly' | 'monthly' | 'yearly';
export type ReportFormat = 'json' | 'pdf' | 'excel';

export class ReportQueryDto {
  @IsIn(['daily', 'weekly', 'monthly', 'yearly'])
  period: ReportPeriod;

  @IsIn(['json', 'pdf', 'excel'])
  format: ReportFormat;
}
