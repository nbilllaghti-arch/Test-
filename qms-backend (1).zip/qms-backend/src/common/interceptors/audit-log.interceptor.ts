import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { PrismaService } from '../../prisma/prisma.service';

/**
 * Attach via @UseInterceptors(AuditLogInterceptor) on any staff-facing
 * mutating endpoint. Reads `req.auditAction` / `req.auditEntity`, which
 * the controller method sets just before returning, e.g.:
 *   req.auditAction = 'ticket.call_next'; req.auditEntity = { type: 'ticket', id };
 */
@Injectable()
export class AuditLogInterceptor implements NestInterceptor {
  constructor(private prisma: PrismaService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const req = context.switchToHttp().getRequest();

    return next.handle().pipe(
      tap(async () => {
        if (!req.auditAction) return;
        await this.prisma.auditLog.create({
          data: {
            userId: req.user?.id ?? null,
            action: req.auditAction,
            entityType: req.auditEntity?.type ?? 'unknown',
            entityId: req.auditEntity?.id ?? null,
            metadata: req.auditMetadata ?? undefined,
            ipAddress: req.ip,
          },
        });
      }),
    );
  }
}
