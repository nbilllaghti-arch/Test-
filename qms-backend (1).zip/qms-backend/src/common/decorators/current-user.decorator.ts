import { createParamDecorator, ExecutionContext } from '@nestjs/common';

/**
 * Populated by JwtStrategy.validate() and attached to req.user by Passport.
 */
export interface AuthenticatedUser {
  id: string;
  role: string;
  organizationId: string | null;
  branchId: string | null;
}

export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): AuthenticatedUser => {
    const request = ctx.switchToHttp().getRequest();
    return request.user;
  },
);
