import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { TicketsService } from './tickets.service';
import { JoinQueueDto, RateTicketDto, TransferTicketDto } from './dto/ticket.dto';

@Controller()
export class TicketsController {
  constructor(private ticketsService: TicketsService) {}

  // ---------- Customer-facing ----------

  @UseGuards(JwtAuthGuard)
  @Throttle({ default: { limit: 5, ttl: 60_000 } }) // prevent ticket-spamming a queue
  @Post('queues/:queueId/join')
  join(@Param('queueId') queueId: string, @CurrentUser() user: AuthenticatedUser, @Body() dto: JoinQueueDto) {
    return this.ticketsService.join(queueId, user.id, dto);
  }

  @UseGuards(JwtAuthGuard)
  @Get('tickets/:id')
  getStatus(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.ticketsService.getStatus(id, user);
  }

  @UseGuards(JwtAuthGuard)
  @Post('tickets/:id/cancel')
  cancel(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.ticketsService.cancel(id, user);
  }

  @UseGuards(JwtAuthGuard)
  @Post('tickets/:id/rating')
  rate(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser, @Body() dto: RateTicketDto) {
    return this.ticketsService.rate(id, user, dto);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception', 'employee')
  @Get('queues/:queueId/tickets')
  listTickets(@Param('queueId') queueId: string, @CurrentUser() user: AuthenticatedUser, @Query('status') status?: string) {
    return this.ticketsService.listTickets(queueId, user, status);
  }

  // ---------- Staff-facing ----------

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception', 'employee')
  @Post('queues/:queueId/call-next')
  callNext(@Param('queueId') queueId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.ticketsService.callNext(queueId, user);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception', 'employee')
  @Post('tickets/:id/recall')
  recall(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.ticketsService.recall(id, user);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception', 'employee')
  @Post('tickets/:id/complete')
  complete(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.ticketsService.complete(id, user);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception', 'employee')
  @Post('tickets/:id/skip')
  skip(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.ticketsService.skip(id, user);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception')
  @Post('tickets/:id/transfer')
  transfer(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser, @Body() dto: TransferTicketDto) {
    return this.ticketsService.transfer(id, user, dto.targetQueueId);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('super_admin', 'org_admin', 'branch_admin', 'reception')
  @Post('tickets/:id/priority')
  setPriority(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.ticketsService.setPriority(id, user);
  }
}
