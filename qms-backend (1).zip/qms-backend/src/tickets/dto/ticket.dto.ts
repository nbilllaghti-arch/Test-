import { IsInt, IsOptional, IsString, IsUUID, Max, Min } from 'class-validator';

export class JoinQueueDto {
  @IsOptional()
  @IsString()
  guestName?: string;
}

export class RateTicketDto {
  @IsInt()
  @Min(1)
  @Max(5)
  score: number;

  @IsOptional()
  @IsString()
  comment?: string;
}

export class TransferTicketDto {
  @IsUUID()
  targetQueueId: string;
}
