import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { RealtimeGateway } from '../realtime/realtime.gateway';
import { QueueEngineService } from '../queues/queue-engine.service';
import { NotificationsService } from '../notifications/notifications.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { JoinQueueDto, RateTicketDto } from './dto/ticket.dto';

@Injectable()
export class TicketsService {
  constructor(
    private prisma: PrismaService,
    private realtime: RealtimeGateway,
    private engine: QueueEngineService,
    private notifications: NotificationsService,
  ) {}

  // ---------- Customer-facing ----------

  async join(queueId: string, customerId: string | null, dto: JoinQueueDto) {
    const queue = await this.prisma.queue.findUnique({ where: { id: queueId } });
    if (!queue) throw new NotFoundException('Queue not found');
    if (queue.isPaused) throw new BadRequestException('This queue is currently paused');

    const ticket = await this.prisma.$transaction(async (tx) => {
      const updatedQueue = await tx.queue.update({
        where: { id: queueId },
        data: { nextTicketNumber: { increment: 1 } },
      });
      const ticketNumber = updatedQueue.nextTicketNumber - 1;
      return tx.ticket.create({
        data: {
          queueId,
          ticketNumber,
          customerId,
          guestName: dto.guestName,
        },
      });
    });

    const [position, eta] = await Promise.all([
      this.engine.positionOf(queueId, ticket.id),
      this.engine.estimateWaitSeconds(queueId, ticket.id),
    ]);

    await this.prisma.ticket.update({ where: { id: ticket.id }, data: { estimatedWaitSeconds: eta } });
    this.realtime.emitQueueUpdated(queueId, {
      nowServing: (await this.currentServingNumber(queueId)) ?? 0,
      waitingCount: await this.prisma.ticket.count({ where: { queueId, status: 'waiting' } }),
    });

    return {
      ticketId: ticket.id,
      ticketNumber: ticket.ticketNumber,
      label: `${queue.code}-${String(ticket.ticketNumber).padStart(3, '0')}`,
      position,
      estimatedWaitSeconds: eta,
    };
  }

  async getStatus(ticketId: string, requester: AuthenticatedUser | null) {
    const ticket = await this.getOr404(ticketId);
    this.assertOwnerOrStaff(ticket, requester);

    const position = ticket.status === 'waiting' ? await this.engine.positionOf(ticket.queueId, ticket.id) : 0;
    return { ...ticket, position };
  }

  async cancel(ticketId: string, requester: AuthenticatedUser) {
    const ticket = await this.getOr404(ticketId);
    this.assertOwner(ticket, requester);
    if (ticket.status !== 'waiting') throw new BadRequestException('Only a waiting ticket can be cancelled');

    await this.prisma.ticket.update({ where: { id: ticketId }, data: { status: 'cancelled', cancelledAt: new Date() } });
    await this.engine.recalculateAndBroadcast(ticket.queueId, 'A ticket ahead of you was cancelled');
    this.realtime.emitQueueUpdated(ticket.queueId, {
      nowServing: (await this.currentServingNumber(ticket.queueId)) ?? 0,
      waitingCount: await this.prisma.ticket.count({ where: { queueId: ticket.queueId, status: 'waiting' } }),
    });
    await this.notifications.notify(ticketId, 'cancelled');
    return { status: 'cancelled' };
  }

  async rate(ticketId: string, requester: AuthenticatedUser, dto: RateTicketDto) {
    const ticket = await this.getOr404(ticketId);
    this.assertOwner(ticket, requester);
    if (ticket.status !== 'done') throw new BadRequestException('You can only rate a completed visit');

    return this.prisma.rating.upsert({
      where: { ticketId },
      create: { ticketId, score: dto.score, comment: dto.comment },
      update: { score: dto.score, comment: dto.comment },
    });
  }

  // ---------- Staff-facing ----------

  async callNext(queueId: string, requester: AuthenticatedUser) {
    await this.assertStaffAccess(requester, queueId);

    const alreadyServing = await this.prisma.ticket.findFirst({ where: { queueId, status: 'serving' } });
    if (alreadyServing) throw new BadRequestException('Complete or skip the current ticket before calling the next one');

    const next = await this.prisma.ticket.findFirst({
      where: { queueId, status: 'waiting' },
      orderBy: [{ isPriority: 'desc' }, { joinedAt: 'asc' }],
    });
    if (!next) throw new BadRequestException('No customers waiting in this queue');

    const updated = await this.prisma.ticket.update({
      where: { id: next.id },
      data: { status: 'serving', calledAt: new Date(), servedBy: requester.id },
    });

    const queue = await this.prisma.queue.findUniqueOrThrow({ where: { id: queueId } });
    const label = `${queue.code}-${String(updated.ticketNumber).padStart(3, '0')}`;
    this.realtime.emitTicketCalled(queueId, { ticketId: updated.id, label });
    this.realtime.emitQueueUpdated(queueId, {
      nowServing: updated.ticketNumber,
      waitingCount: await this.prisma.ticket.count({ where: { queueId, status: 'waiting' } }),
    });
    await this.notifications.notify(updated.id, 'called');
    return updated;
  }

  async recall(ticketId: string, requester: AuthenticatedUser) {
    const ticket = await this.getOr404(ticketId);
    await this.assertStaffAccess(requester, ticket.queueId);
    if (ticket.status !== 'serving') throw new BadRequestException('Only the currently-serving ticket can be recalled');

    const queue = await this.prisma.queue.findUniqueOrThrow({ where: { id: ticket.queueId } });
    const label = `${queue.code}-${String(ticket.ticketNumber).padStart(3, '0')}`;
    this.realtime.emitTicketCalled(ticket.queueId, { ticketId: ticket.id, label });
    return { recalled: true };
  }

  async complete(ticketId: string, requester: AuthenticatedUser) {
    const ticket = await this.getOr404(ticketId);
    await this.assertStaffAccess(requester, ticket.queueId);
    if (ticket.status !== 'serving') throw new BadRequestException('Only a ticket currently being served can be completed');

    const completedAt = new Date();
    const durationSeconds = ticket.calledAt ? Math.round((completedAt.getTime() - ticket.calledAt.getTime()) / 1000) : null;

    await this.prisma.$transaction(async (tx) => {
      await tx.ticket.update({ where: { id: ticketId }, data: { status: 'done', completedAt } });
      if (durationSeconds !== null) {
        await tx.serviceSample.create({
          data: { queueId: ticket.queueId, employeeId: requester.id, ticketId, durationSeconds },
        });
      }
    });

    await this.engine.recalculateAndBroadcast(ticket.queueId, 'Estimate updated based on latest service time');
    this.realtime.emitQueueUpdated(ticket.queueId, {
      nowServing: 0,
      waitingCount: await this.prisma.ticket.count({ where: { queueId: ticket.queueId, status: 'waiting' } }),
    });
    return { status: 'done' };
  }

  async skip(ticketId: string, requester: AuthenticatedUser) {
    const ticket = await this.getOr404(ticketId);
    await this.assertStaffAccess(requester, ticket.queueId);
    if (!['serving', 'waiting'].includes(ticket.status)) throw new BadRequestException('This ticket cannot be skipped');

    await this.prisma.ticket.update({ where: { id: ticketId }, data: { status: 'skipped' } });
    this.realtime.emitTicketSkipped(ticket.queueId, { ticketId });
    await this.engine.recalculateAndBroadcast(ticket.queueId, 'A ticket ahead of you was skipped');
    await this.notifications.notify(ticketId, 'skipped');
    return { status: 'skipped' };
  }

  /** Called by the scheduled no-show checker — same effect as skip() but without a staff requester. */
  async skipForNoShow(ticketId: string) {
    const ticket = await this.getOr404(ticketId);
    if (ticket.status !== 'serving') return;

    await this.prisma.ticket.update({ where: { id: ticketId }, data: { status: 'skipped' } });
    this.realtime.emitTicketSkipped(ticket.queueId, { ticketId });
    this.realtime.emitQueueUpdated(ticket.queueId, {
      nowServing: 0,
      waitingCount: await this.prisma.ticket.count({ where: { queueId: ticket.queueId, status: 'waiting' } }),
    });
    await this.engine.recalculateAndBroadcast(ticket.queueId, 'Previous customer did not appear in time');
    await this.notifications.notify(ticketId, 'skipped');
  }

  async transfer(ticketId: string, requester: AuthenticatedUser, targetQueueId: string) {
    const ticket = await this.getOr404(ticketId);
    await this.assertStaffAccess(requester, ticket.queueId);
    await this.assertStaffAccess(requester, targetQueueId);

    const targetQueue = await this.prisma.queue.findUnique({ where: { id: targetQueueId } });
    if (!targetQueue) throw new NotFoundException('Target queue not found');

    const newTicket = await this.prisma.$transaction(async (tx) => {
      await tx.ticket.update({ where: { id: ticketId }, data: { status: 'cancelled', cancelledAt: new Date() } });
      const updatedTarget = await tx.queue.update({
        where: { id: targetQueueId },
        data: { nextTicketNumber: { increment: 1 } },
      });
      return tx.ticket.create({
        data: {
          queueId: targetQueueId,
          ticketNumber: updatedTarget.nextTicketNumber - 1,
          customerId: ticket.customerId,
          guestName: ticket.guestName,
          isPriority: ticket.isPriority,
        },
      });
    });

    await this.engine.recalculateAndBroadcast(ticket.queueId, 'A ticket ahead of you was transferred');
    await this.engine.recalculateAndBroadcast(targetQueueId, 'A ticket was transferred into this queue');
    return newTicket;
  }

  async setPriority(ticketId: string, requester: AuthenticatedUser) {
    const ticket = await this.getOr404(ticketId);
    await this.assertStaffAccess(requester, ticket.queueId);
    if (ticket.status !== 'waiting') throw new BadRequestException('Only a waiting ticket can be prioritized');

    await this.prisma.ticket.update({ where: { id: ticketId }, data: { isPriority: true } });
    await this.engine.recalculateAndBroadcast(ticket.queueId, 'Queue order updated for a priority customer');
    return { isPriority: true };
  }

  async listTickets(queueId: string, requester: AuthenticatedUser, status?: string) {
    await this.assertStaffAccess(requester, queueId);
    return this.prisma.ticket.findMany({
      where: { queueId, ...(status ? { status: status as any } : {}) },
      orderBy: [{ isPriority: 'desc' }, { joinedAt: 'asc' }],
    });
  }

  // ---------- Helpers ----------

  private async currentServingNumber(queueId: string) {
    const serving = await this.prisma.ticket.findFirst({ where: { queueId, status: 'serving' } });
    return serving?.ticketNumber ?? null;
  }

  private async getOr404(ticketId: string) {
    const ticket = await this.prisma.ticket.findUnique({ where: { id: ticketId } });
    if (!ticket) throw new NotFoundException('Ticket not found');
    return ticket;
  }

  private assertOwner(ticket: { customerId: string | null }, requester: AuthenticatedUser) {
    if (ticket.customerId !== requester.id) throw new ForbiddenException('This is not your ticket');
  }

  private assertOwnerOrStaff(ticket: { customerId: string | null; queueId: string }, requester: AuthenticatedUser | null) {
    if (!requester) throw new ForbiddenException('Authentication required');
    if (ticket.customerId === requester.id) return;
    if (['super_admin', 'org_admin', 'branch_admin', 'reception', 'employee'].includes(requester.role)) return;
    throw new ForbiddenException('This is not your ticket');
  }

  private async assertStaffAccess(requester: AuthenticatedUser, queueId: string) {
    if (requester.role === 'super_admin' || requester.role === 'org_admin') return;
    if (!['branch_admin', 'reception', 'employee'].includes(requester.role)) {
      throw new ForbiddenException('Staff access required');
    }
    const queue = await this.prisma.queue.findUnique({ where: { id: queueId } });
    if (!queue) throw new NotFoundException('Queue not found');
    if (queue.branchId !== requester.branchId) throw new ForbiddenException('You do not have access to this queue');
  }
}
