import { Module } from '@nestjs/common';
import { SchedulerService } from './scheduler.service';
import { TicketsModule } from '../tickets/tickets.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [TicketsModule, NotificationsModule],
  providers: [SchedulerService],
})
export class SchedulerModule {}
