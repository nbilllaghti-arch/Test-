import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../prisma/prisma.service';
import { TicketsService } from '../tickets/tickets.service';
import { NotificationsService } from '../notifications/notifications.service';

const ETA_THRESHOLDS: Array<{ seconds: number; eventType: 'eta_15_min' | 'eta_10_min' | 'eta_5_min' }> = [
  { seconds: 900, eventType: 'eta_15_min' },
  { seconds: 600, eventType: 'eta_10_min' },
  { seconds: 300, eventType: 'eta_5_min' },
];

@Injectable()
export class SchedulerService {
  private readonly logger = new Logger(SchedulerService.name);

  constructor(
    private prisma: PrismaService,
    private ticketsService: TicketsService,
    private notifications: NotificationsService,
  ) {}

  /**
   * Every 30s: find tickets stuck in `serving` past their queue's
   * no_show_timeout_seconds and auto-skip them ("Skip customers who fail
   * to appear after a configurable timeout").
   */
  @Cron(CronExpression.EVERY_30_SECONDS)
  async checkNoShows() {
    const servingTickets = await this.prisma.ticket.findMany({
      where: { status: 'serving', calledAt: { not: null } },
      include: { queue: true },
    });

    const now = Date.now();
    const overdue = servingTickets.filter((t) => {
      const calledAt = t.calledAt!.getTime();
      return now - calledAt > t.queue.noShowTimeoutSeconds * 1000;
    });

    for (const ticket of overdue) {
      this.logger.log(`Auto-skipping no-show ticket ${ticket.id} in queue ${ticket.queueId}`);
      await this.ticketsService.skipForNoShow(ticket.id);
    }
  }

  /**
   * Every 30s: check waiting tickets against the 15/10/5-minute ETA
   * thresholds and notify once per threshold (deduped via the
   * notifications log, since ETAs fluctuate up and down over time).
   */
  @Cron(CronExpression.EVERY_30_SECONDS)
  async checkEtaThresholds() {
    const waiting = await this.prisma.ticket.findMany({
      where: { status: 'waiting', estimatedWaitSeconds: { not: null } },
    });

    for (const ticket of waiting) {
      for (const threshold of ETA_THRESHOLDS) {
        if (ticket.estimatedWaitSeconds! > threshold.seconds) continue;
        const already = await this.notifications.hasBeenNotified(ticket.id, threshold.eventType);
        if (already) continue;
        await this.notifications.notify(ticket.id, threshold.eventType);
      }
    }
  }
}
