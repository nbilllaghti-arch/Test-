import { WebSocketGateway, WebSocketServer, SubscribeMessage, MessageBody, ConnectedSocket } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

/**
 * Clients subscribe to `queue:{queueId}` (customers, display screens) and
 * `branch:{branchId}` (staff dashboards watching several queues at once).
 * All emit methods here are called from QueuesService / TicketsService
 * after a state change is persisted — never speculatively.
 */
@WebSocketGateway({ cors: { origin: '*' }, namespace: '/realtime' })
export class RealtimeGateway {
  @WebSocketServer()
  server: Server;

  @SubscribeMessage('subscribe:queue')
  onSubscribeQueue(@MessageBody() queueId: string, @ConnectedSocket() client: Socket) {
    client.join(`queue:${queueId}`);
  }

  @SubscribeMessage('subscribe:branch')
  onSubscribeBranch(@MessageBody() branchId: string, @ConnectedSocket() client: Socket) {
    client.join(`branch:${branchId}`);
  }

  emitQueueUpdated(queueId: string, payload: { nowServing: number; waitingCount: number }) {
    this.server.to(`queue:${queueId}`).emit('queue.updated', payload);
  }

  emitTicketCalled(queueId: string, payload: { ticketId: string; label: string }) {
    this.server.to(`queue:${queueId}`).emit('ticket.called', payload);
  }

  emitTicketEtaChanged(queueId: string, payload: { ticketId: string; estimatedWaitSeconds: number; reason: string }) {
    this.server.to(`queue:${queueId}`).emit('ticket.eta_changed', payload);
  }

  emitTicketSkipped(queueId: string, payload: { ticketId: string }) {
    this.server.to(`queue:${queueId}`).emit('ticket.skipped', payload);
  }

  emitQueuePauseState(queueId: string, paused: boolean) {
    this.server.to(`queue:${queueId}`).emit(paused ? 'queue.paused' : 'queue.resumed', { queueId });
  }
}
