import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';

@Injectable()
export class OrganizationsService {
  constructor(private prisma: PrismaService) {}

  create(name: string) {
    return this.prisma.organization.create({ data: { name } });
  }

  async update(
    id: string,
    requester: AuthenticatedUser,
    data: { name?: string; logoUrl?: string; brandColor?: string },
  ) {
    this.assertOwnsOrg(requester, id);
    const org = await this.prisma.organization.findUnique({ where: { id } });
    if (!org) throw new NotFoundException('Organization not found');
    return this.prisma.organization.update({ where: { id }, data });
  }

  findById(id: string) {
    return this.prisma.organization.findUnique({ where: { id }, include: { branches: true } });
  }

  /** org_admin can only touch their own organization; super_admin can touch any. */
  private assertOwnsOrg(requester: AuthenticatedUser, orgId: string) {
    if (requester.role === 'super_admin') return;
    if (requester.role === 'org_admin' && requester.organizationId === orgId) return;
    throw new ForbiddenException('You do not have access to this organization');
  }
}
