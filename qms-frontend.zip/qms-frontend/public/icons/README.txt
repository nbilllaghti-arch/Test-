Place your app icons here:
  icon-192.png          192x192
  icon-512.png          512x512
  icon-512-maskable.png 512x512, with safe-zone padding for maskable display

`next-pwa` and manifest.json already reference these exact filenames — just
drop your branded PNGs in with these names and the PWA install prompt,
home-screen icon, and splash screen will all pick them up automatically.
