# Waitline — Frontend (Customer Portal, Admin Dashboard, Public Display)

Next.js 14 (App Router) + TypeScript + Tailwind CSS. A PWA (installable,
offline app-shell via `next-pwa`) with English/Arabic localization (RTL),
dark/light mode, and realtime updates via Socket.io, talking to the
`qms-backend` NestJS API.

## Setup

```bash
npm install
cp .env.example .env.local   # point at your running qms-backend
npm run dev
```

Icons: drop `icon-192.png`, `icon-512.png`, `icon-512-maskable.png` into
`public/icons/` (see the README there) — binary image assets can't be
generated as source code, everything else is wired up to use them.

## Route map

```
/{locale}/                          landing (choose customer / staff)
/{locale}/login                     staff + customer login
/{locale}/register                  org_admin signup (creates an org) or customer signup
/{locale}/join?branch={branchId}    customer: browse queues at a branch
/{locale}/join/{queueId}            customer: join a specific queue
/{locale}/qr/{token}                customer: QR scan entry point → resolves → join flow
/{locale}/ticket/{ticketId}         customer: live ticket status (realtime)
/{locale}/display/{queueId}         public display screen (lobby monitor, no auth)

/{locale}/admin/dashboard           aggregated live stats across accessible branches
/{locale}/admin/organizations       organization profile
/{locale}/admin/branches            branch list/create (org_admin) or own-branch view (branch_admin)
/{locale}/admin/queues              queue list/create
/{locale}/admin/queues/{queueId}    queue control panel: call-next, complete, skip, pause,
                                     QR generation, waiting list, priority
/{locale}/admin/employees           staff list/invite, queue assignment
/{locale}/admin/reports             daily/weekly/monthly/yearly reports, PDF/Excel download
/{locale}/admin/settings            white-label branding (org_admin), preference sync
```

`{locale}` is `en` or `ar` — middleware redirects `/` based on a `locale`
cookie or `Accept-Language`, and `LanguageSwitcher` flips it (and the
`dir` attribute) at runtime.

## Architecture

```
src/
  app/[locale]/       routes (see map above)
  components/
    ui/               Button, Card, Input, Select, Badge, Modal, Spinner, FlapNumber
    layout/           AdminSidebar, AdminTopbar, LanguageSwitcher, ThemeToggle
    auth/              LoginForm, RegisterForm, AuthGuard
    queues/            QueueControlPanel
    tickets/           TicketStub
  lib/
    api/               one file per backend domain (auth, users, organizations,
                       branches, queues, tickets, reports, staff) — all typed,
                       all calling the real NestJS endpoints
    auth/              AuthContext — token storage, login/register/guest/logout
    realtime/          socket.ts (singleton client) + useQueueRealtime hook
    i18n/               dictionaries (en.json, ar.json) + getDictionary/t helpers
    theme/              ThemeProvider (dark/light, persisted to localStorage)
  types/                shared TS types mirroring backend DTOs
```

Every admin page fetches from the real backend routes documented in
`qms-api-contract.md` (plus a handful of endpoints added alongside this
frontend pass — see below). Nothing renders from mock data.

## Endpoints added to the backend to support this frontend

The original backend pass didn't expose a few reads the UI genuinely
needs. These were added to `qms-backend` in this pass, following the same
RBAC/scoping patterns as the rest of the API:

- `GET /branches/:branchId/queues` — public, list queues at a branch (customer join page)
- `GET /branches/:id` — staff-scoped, fetch a single branch's details
- `GET /queues/:queueId/tickets?status=` — staff-scoped, list tickets for the control panel's waiting list
- `GET /organizations/:orgId/staff` / `POST /organizations/:orgId/staff` — org_admin manages staff accounts

## Realtime

`useQueueRealtime(queueId, { onQueueUpdated, onTicketCalled, ... })`
subscribes to `queue:{queueId}` on the backend's `/realtime` Socket.io
namespace and re-fetches the relevant data on each event. A 10–15s poll
runs alongside it as a fallback if the socket disconnects.

## Localization & RTL

- `lib/i18n/dictionaries/{en,ar}.json` — flat, dotted-path translation keys
- `<body dir={...}>` is set per-locale in `app/[locale]/layout.tsx`
- Components use logical Tailwind utilities (`ms-`, `me-`, `border-s`,
  `border-e`, `text-start`) instead of `ml-`/`mr-`/`text-left` so spacing
  and alignment mirror automatically in Arabic — check new components
  against this convention as you extend the UI.

## What's implemented vs. left as next steps

Implemented: every route in the map above with real API calls and
realtime updates; JWT auth with refresh rotation and guest sessions;
RBAC-aware admin shell (branch_admin only sees their branch, org_admin
sees everything in their org); full ticket lifecycle from both the
customer and staff sides; QR generation (payload string — see below);
reports with a peak-hours chart and PDF/Excel download; white-label
branding; i18n EN/AR with RTL; dark/light mode; PWA manifest + service
worker via `next-pwa`; production Dockerfile with standalone output.

Not yet implemented (flagged so nothing is assumed silently):
- **Push notification registration**: the backend can deliver to a
  `pushToken` on the user record, but the frontend doesn't yet register
  a service-worker push subscription (browser Push API / FCM Web SDK) and
  save it via `PATCH /users/me/preferences`-style call — that's a
  browser-permissions flow worth wiring deliberately rather than
  silently, since it prompts the user.
- **Automated tests** (unit/e2e) — none included yet.
- **Multi-organization super_admin console** — `super_admin` can log in
  and use every screen, but there's no "list all organizations" page;
  the backend only exposes get/update by ID, not list-all, so that's a
  backend addition too if you want a true platform-operator view.
