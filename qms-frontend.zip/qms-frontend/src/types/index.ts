export type UserRole = 'super_admin' | 'org_admin' | 'branch_admin' | 'employee' | 'reception' | 'customer';
export type JoinMode = 'remote' | 'qr' | 'both';
export type TicketStatus = 'waiting' | 'serving' | 'done' | 'skipped' | 'cancelled';

export interface AuthUser {
  id: string;
  role: UserRole;
  organizationId: string | null;
  branchId: string | null;
  fullName?: string | null;
  email?: string | null;
}

export interface Organization {
  id: string;
  name: string;
  logoUrl: string | null;
  brandColor: string | null;
  isActive: boolean;
  createdAt: string;
  branches?: Branch[];
}

export interface Branch {
  id: string;
  organizationId: string;
  name: string;
  address: string | null;
  timezone: string;
  isActive: boolean;
}

export interface Queue {
  id: string;
  branchId: string;
  name: string;
  code: string;
  joinMode: JoinMode;
  avgServiceSeconds: number;
  noShowTimeoutSeconds: number;
  isPaused: boolean;
  priorityEnabled: boolean;
  nextTicketNumber: number;
  nowServing?: number;
  waitingCount?: number;
  servedToday?: number;
}

export interface Ticket {
  id: string;
  queueId: string;
  ticketNumber: number;
  label?: string;
  status: TicketStatus;
  isPriority: boolean;
  position?: number;
  estimatedWaitSeconds?: number | null;
  joinedAt: string;
  calledAt?: string | null;
  completedAt?: string | null;
}

export interface ReportData {
  branchName: string;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly';
  rangeStart: string;
  rangeEnd: string;
  totalTickets: number;
  servedCount: number;
  cancelledCount: number;
  skippedCount: number;
  cancellationRate: number;
  noShowRate: number;
  avgWaitSeconds: number;
  avgServiceSeconds: number;
  peakHours: Array<{ hour: number; count: number }>;
  employeePerformance: Array<{ employeeName: string; served: number; avgServiceSeconds: number }>;
}
