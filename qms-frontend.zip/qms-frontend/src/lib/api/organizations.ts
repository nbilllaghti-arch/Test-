import { api } from './client';
import { Organization } from '@/types';

export const organizationsApi = {
  get: (id: string) => api.get<Organization>(`/organizations/${id}`),
  update: (id: string, data: { name?: string; logoUrl?: string; brandColor?: string }) =>
    api.patch<Organization>(`/organizations/${id}`, data),
};
