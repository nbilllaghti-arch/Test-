import { api } from './client';
import { ReportData } from '@/types';

export type ReportPeriod = 'daily' | 'weekly' | 'monthly' | 'yearly';

export const reportsApi = {
  getJson: (branchId: string, period: ReportPeriod) =>
    api.get<ReportData>(`/branches/${branchId}/reports?period=${period}&format=json`),

  async download(branchId: string, period: ReportPeriod, format: 'pdf' | 'excel') {
    const res = await api.rawGet(`/branches/${branchId}/reports?period=${period}&format=${format}`);
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `report.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  },
};
