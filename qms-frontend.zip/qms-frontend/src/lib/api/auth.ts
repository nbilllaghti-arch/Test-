import { api } from './client';

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  role: string;
}

export const authApi = {
  register: (data: { role: 'org_admin' | 'customer'; fullName: string; email: string; password: string; organizationName?: string }) =>
    api.post<AuthResponse>('/auth/register', data, { auth: false }),

  login: (data: { email: string; password: string }) =>
    api.post<AuthResponse>('/auth/login', data, { auth: false }),

  refresh: (refreshToken: string) =>
    api.post<AuthResponse>('/auth/refresh', { refreshToken }, { auth: false }),

  guestSession: () => api.post<{ userId: string; accessToken: string }>('/auth/guest-session', {}, { auth: false }),
};
