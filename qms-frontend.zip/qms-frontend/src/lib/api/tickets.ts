import { api } from './client';
import { Ticket } from '@/types';

export const ticketsApi = {
  listForQueue: (queueId: string, status?: string) =>
    api.get<Ticket[]>(`/queues/${queueId}/tickets${status ? `?status=${status}` : ''}`),

  join: (queueId: string, guestName?: string) => api.post<Ticket>(`/queues/${queueId}/join`, { guestName }),

  getStatus: (id: string) => api.get<Ticket>(`/tickets/${id}`),

  cancel: (id: string) => api.post(`/tickets/${id}/cancel`),

  rate: (id: string, score: number, comment?: string) => api.post(`/tickets/${id}/rating`, { score, comment }),

  callNext: (queueId: string) => api.post<Ticket>(`/queues/${queueId}/call-next`),

  recall: (id: string) => api.post(`/tickets/${id}/recall`),

  complete: (id: string) => api.post(`/tickets/${id}/complete`),

  skip: (id: string) => api.post(`/tickets/${id}/skip`),

  transfer: (id: string, targetQueueId: string) => api.post(`/tickets/${id}/transfer`, { targetQueueId }),

  setPriority: (id: string) => api.post(`/tickets/${id}/priority`),
};
