import { api } from './client';
import { Queue } from '@/types';

export const queuesApi = {
  listForBranch: (branchId: string) => api.get<Queue[]>(`/branches/${branchId}/queues`, { auth: false }),

  create: (branchId: string, data: { name: string; code: string; joinMode?: string; avgServiceSeconds?: number; noShowTimeoutSeconds?: number }) =>
    api.post<Queue>(`/branches/${branchId}/queues`, data),

  liveStatus: (id: string) => api.get<Queue>(`/queues/${id}`, { auth: false }),

  display: (id: string) => api.get<Queue>(`/queues/${id}/display`, { auth: false }),

  update: (id: string, data: Partial<Pick<Queue, 'name' | 'joinMode' | 'avgServiceSeconds' | 'noShowTimeoutSeconds' | 'priorityEnabled'>>) =>
    api.patch<Queue>(`/queues/${id}`, data),

  assignEmployee: (id: string, userId: string) => api.post(`/queues/${id}/employees`, { userId }),

  generateQrToken: (id: string) => api.post<{ token: string; qrPayload: string }>(`/queues/${id}/qr-token`, {}),

  resolveQrToken: (token: string) => api.post<Queue>(`/qr/${token}/resolve`, {}, { auth: false }),

  pause: (id: string) => api.post<Queue>(`/queues/${id}/pause`, {}),
  resume: (id: string) => api.post<Queue>(`/queues/${id}/resume`, {}),
};
