import { api } from './client';
import { Branch } from '@/types';

export const branchesApi = {
  get: (id: string) => api.get<Branch>(`/branches/${id}`),
  list: (organizationId: string) => api.get<Branch[]>(`/organizations/${organizationId}/branches`),
  create: (organizationId: string, data: { name: string; address?: string; timezone?: string }) =>
    api.post<Branch>(`/organizations/${organizationId}/branches`, data),
  update: (id: string, data: { name?: string; address?: string; timezone?: string; isActive?: boolean }) =>
    api.patch<Branch>(`/branches/${id}`, data),
};
