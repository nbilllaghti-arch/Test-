import { api } from './client';
import { AuthUser } from '@/types';

export const usersApi = {
  me: () => api.get<AuthUser>('/users/me'),
  updatePreferences: (data: { language?: string; darkMode?: boolean }) =>
    api.patch('/users/me/preferences', data),
};
