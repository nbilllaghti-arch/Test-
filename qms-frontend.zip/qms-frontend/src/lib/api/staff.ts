import { api } from './client';
import { AuthUser } from '@/types';

export interface StaffMember extends AuthUser {
  createdAt: string;
}

export const staffApi = {
  list: (organizationId: string) => api.get<StaffMember[]>(`/organizations/${organizationId}/staff`),
  create: (
    organizationId: string,
    data: { role: 'branch_admin' | 'employee' | 'reception'; fullName: string; email: string; password: string; branchId?: string },
  ) => api.post<StaffMember>(`/organizations/${organizationId}/staff`, data),
};
