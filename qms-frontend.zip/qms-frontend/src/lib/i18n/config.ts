import en from './dictionaries/en.json';
import ar from './dictionaries/ar.json';

export const locales = ['en', 'ar'] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = 'en';

export const rtlLocales: Locale[] = ['ar'];

const dictionaries = { en, ar };

export type Dictionary = typeof en;

export function getDictionary(locale: Locale): Dictionary {
  return dictionaries[locale] ?? dictionaries[defaultLocale];
}

export function isRtl(locale: Locale): boolean {
  return rtlLocales.includes(locale);
}

/** Simple dotted-path translator, e.g. t(dict, 'admin.dashboard'). */
export function t(dict: Dictionary, path: string): string {
  const parts = path.split('.');
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let node: any = dict;
  for (const part of parts) {
    node = node?.[part];
  }
  return typeof node === 'string' ? node : path;
}
