'use client';

import { useEffect, useRef, useState } from 'react';
import { getSocket } from './socket';

export interface QueueUpdatedPayload {
  nowServing: number;
  waitingCount: number;
}
export interface TicketCalledPayload {
  ticketId: string;
  label: string;
}
export interface TicketEtaChangedPayload {
  ticketId: string;
  estimatedWaitSeconds: number;
  reason: string;
}
export interface TicketSkippedPayload {
  ticketId: string;
}

interface QueueRealtimeEvents {
  onQueueUpdated?: (payload: QueueUpdatedPayload) => void;
  onTicketCalled?: (payload: TicketCalledPayload) => void;
  onTicketEtaChanged?: (payload: TicketEtaChangedPayload) => void;
  onTicketSkipped?: (payload: TicketSkippedPayload) => void;
  onQueuePaused?: () => void;
  onQueueResumed?: () => void;
}

/** Subscribes to `queue:{queueId}` and wires up the event callbacks for the lifetime of the component. */
export function useQueueRealtime(queueId: string | null, events: QueueRealtimeEvents) {
  const [connected, setConnected] = useState(false);
  const eventsRef = useRef(events);
  eventsRef.current = events;

  useEffect(() => {
    if (!queueId) return;
    const socket = getSocket();

    const onConnect = () => {
      setConnected(true);
      socket.emit('subscribe:queue', queueId);
    };
    const onQueueUpdated = (p: QueueUpdatedPayload) => eventsRef.current.onQueueUpdated?.(p);
    const onTicketCalled = (p: TicketCalledPayload) => eventsRef.current.onTicketCalled?.(p);
    const onTicketEtaChanged = (p: TicketEtaChangedPayload) => eventsRef.current.onTicketEtaChanged?.(p);
    const onTicketSkipped = (p: TicketSkippedPayload) => eventsRef.current.onTicketSkipped?.(p);
    const onQueuePaused = () => eventsRef.current.onQueuePaused?.();
    const onQueueResumed = () => eventsRef.current.onQueueResumed?.();

    socket.on('connect', onConnect);
    socket.on('queue.updated', onQueueUpdated);
    socket.on('ticket.called', onTicketCalled);
    socket.on('ticket.eta_changed', onTicketEtaChanged);
    socket.on('ticket.skipped', onTicketSkipped);
    socket.on('queue.paused', onQueuePaused);
    socket.on('queue.resumed', onQueueResumed);

    if (socket.connected) onConnect();

    return () => {
      socket.off('connect', onConnect);
      socket.off('queue.updated', onQueueUpdated);
      socket.off('ticket.called', onTicketCalled);
      socket.off('ticket.eta_changed', onTicketEtaChanged);
      socket.off('ticket.skipped', onTicketSkipped);
      socket.off('queue.paused', onQueuePaused);
      socket.off('queue.resumed', onQueueResumed);
    };
  }, [queueId]);

  return { connected };
}
