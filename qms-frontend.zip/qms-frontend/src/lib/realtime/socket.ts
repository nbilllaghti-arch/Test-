import { io, Socket } from 'socket.io-client';

const REALTIME_URL = process.env.NEXT_PUBLIC_REALTIME_URL ?? 'http://localhost:3000';

let socket: Socket | null = null;

export function getSocket(): Socket {
  if (!socket) {
    socket = io(`${REALTIME_URL}/realtime`, { transports: ['websocket'], autoConnect: true });
  }
  return socket;
}
