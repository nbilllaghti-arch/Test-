'use client';

import { createContext, useCallback, useContext, useEffect, useRef, useState, ReactNode } from 'react';
import { authApi } from '../api/auth';
import { usersApi } from '../api/users';
import { registerAuthHooks } from '../api/client';
import { AuthUser } from '@/types';

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: { role: 'org_admin' | 'customer'; fullName: string; email: string; password: string; organizationName?: string }) => Promise<void>;
  continueAsGuest: () => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const ACCESS_KEY = 'qms_access_token';
const REFRESH_KEY = 'qms_refresh_token';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const accessTokenRef = useRef<string | null>(null);

  const persistTokens = useCallback((accessToken: string, refreshToken?: string) => {
    accessTokenRef.current = accessToken;
    window.localStorage.setItem(ACCESS_KEY, accessToken);
    if (refreshToken) window.localStorage.setItem(REFRESH_KEY, refreshToken);
  }, []);

  const clearTokens = useCallback(() => {
    accessTokenRef.current = null;
    window.localStorage.removeItem(ACCESS_KEY);
    window.localStorage.removeItem(REFRESH_KEY);
  }, []);

  const doRefresh = useCallback(async (): Promise<string | null> => {
    const refreshToken = window.localStorage.getItem(REFRESH_KEY);
    if (!refreshToken) return null;
    try {
      const res = await authApi.refresh(refreshToken);
      persistTokens(res.accessToken, res.refreshToken);
      return res.accessToken;
    } catch {
      clearTokens();
      setUser(null);
      return null;
    }
  }, [persistTokens, clearTokens]);

  useEffect(() => {
    registerAuthHooks(() => accessTokenRef.current, doRefresh);

    const stored = window.localStorage.getItem(ACCESS_KEY);
    if (stored) {
      accessTokenRef.current = stored;
      usersApi
        .me()
        .then(setUser)
        .catch(() => clearTokens())
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = useCallback(
    async (email: string, password: string) => {
      const res = await authApi.login({ email, password });
      persistTokens(res.accessToken, res.refreshToken);
      setUser(await usersApi.me());
    },
    [persistTokens],
  );

  const register = useCallback(
    async (data: Parameters<AuthContextValue['register']>[0]) => {
      const res = await authApi.register(data);
      persistTokens(res.accessToken, res.refreshToken);
      setUser(await usersApi.me());
    },
    [persistTokens],
  );

  const continueAsGuest = useCallback(async () => {
    const res = await authApi.guestSession();
    persistTokens(res.accessToken);
    setUser({ id: res.userId, role: 'customer', organizationId: null, branchId: null });
  }, [persistTokens]);

  const logout = useCallback(() => {
    clearTokens();
    setUser(null);
  }, [clearTokens]);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, continueAsGuest, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
