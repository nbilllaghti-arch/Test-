'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { queuesApi } from '../../../../lib/api/queues';
import { ticketsApi } from '../../../../lib/api/tickets';
import { useAuth } from '../../../../lib/auth/AuthContext';
import { Queue } from '@/types';
import { Card } from '../../../../components/ui/Card';
import { Input } from '../../../../components/ui/Input';
import { Button } from '../../../../components/ui/Button';
import { Spinner } from '../../../../components/ui/Spinner';

export default function JoinQueuePage() {
  const params = useParams();
  const router = useRouter();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const queueId = params?.queueId as string;
  const dict = getDictionary(locale);
  const { user, continueAsGuest } = useAuth();

  const [queue, setQueue] = useState<Queue | null>(null);
  const [guestName, setGuestName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    queuesApi.liveStatus(queueId).then(setQueue).catch(() => setError(t(dict, 'common.error')));
  }, [queueId]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleJoin = async () => {
    setSubmitting(true);
    setError(null);
    try {
      if (!user) await continueAsGuest();
      const ticket = await ticketsApi.join(queueId, guestName || undefined);
      router.push(`/${locale}/ticket/${ticket.id}`);
    } catch {
      setError(t(dict, 'common.error'));
    } finally {
      setSubmitting(false);
    }
  };

  if (!queue) {
    return (
      <main className="flex min-h-screen items-center justify-center">
        <Spinner />
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-md px-5 py-10">
      <Card className="p-6">
        <div className="mb-1 text-xs uppercase tracking-wide text-slateSub">{queue.code}</div>
        <h1 className="mb-4 text-xl font-semibold">{queue.name}</h1>
        <p className="mb-4 text-sm text-slateSub">
          {queue.waitingCount ?? 0} {t(dict, 'join.waiting')}
        </p>

        {queue.isPaused ? (
          <p className="text-sm text-red">This queue is currently paused. Please check back shortly.</p>
        ) : (
          <>
            <label className="mb-1 block text-xs text-slateSub">{t(dict, 'join.guestName')}</label>
            <Input value={guestName} onChange={(e) => setGuestName(e.target.value)} className="mb-4" />
            {error && <p className="mb-3 text-xs text-red">{error}</p>}
            <Button onClick={handleJoin} disabled={submitting} className="w-full">
              {t(dict, 'join.joinQueue')}
            </Button>
          </>
        )}
      </Card>
    </main>
  );
}
