'use client';

import { useEffect, useState } from 'react';
import { useSearchParams, useParams, useRouter } from 'next/navigation';
import { QrCode } from 'lucide-react';
import { getDictionary, t } from '../../../lib/i18n/config';
import { queuesApi } from '../../../lib/api/queues';
import { Queue } from '@/types';
import { Card } from '../../../components/ui/Card';
import { Spinner } from '../../../components/ui/Spinner';

export default function JoinPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);
  const branchId = searchParams.get('branch');

  const [queues, setQueues] = useState<Queue[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!branchId) return;
    queuesApi
      .listForBranch(branchId)
      .then(setQueues)
      .catch(() => setError(t(dict, 'common.error')));
  }, [branchId]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <main className="mx-auto max-w-md px-5 py-10">
      <h1 className="mb-1 text-2xl font-semibold">{t(dict, 'join.title')}</h1>
      <p className="mb-6 text-sm text-slateSub">{t(dict, 'join.subtitle')}</p>

      <Card className="mb-4 flex items-center gap-3 p-4">
        <div className="rounded-lg bg-white p-2">
          <QrCode className="h-10 w-10 text-ink" />
        </div>
        <div>
          <div className="text-sm font-medium">{t(dict, 'join.scanInBranch')}</div>
          <div className="text-xs text-slateSub">{t(dict, 'join.scanHint')}</div>
        </div>
      </Card>

      {!branchId && (
        <Card className="p-4 text-sm text-slateSub">
          Open this page from a branch link or scan the QR code posted at the branch to see available queues.
        </Card>
      )}

      {error && <p className="text-sm text-red">{error}</p>}

      {branchId && !queues && !error && (
        <div className="flex justify-center py-8 text-slateSub">
          <Spinner />
        </div>
      )}

      {queues && (
        <div className="space-y-2">
          {queues.map((q) => (
            <button
              key={q.id}
              onClick={() => router.push(`/${locale}/join/${q.id}`)}
              className="flex w-full items-center justify-between rounded-xl border border-paperBorder px-4 py-3 text-start transition hover:border-amber/50 dark:border-inkBorder"
            >
              <span className="text-sm font-medium">{q.name}</span>
              <span className="font-mono text-xs text-slateSub">
                {q.waitingCount ?? 0} {t(dict, 'join.waiting')}
              </span>
            </button>
          ))}
        </div>
      )}
    </main>
  );
}
