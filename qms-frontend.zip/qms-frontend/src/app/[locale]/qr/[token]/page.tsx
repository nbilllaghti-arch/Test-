'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { queuesApi } from '../../../../lib/api/queues';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { Spinner } from '../../../../components/ui/Spinner';

export default function QrResolvePage() {
  const params = useParams();
  const router = useRouter();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const token = params?.token as string;
  const dict = getDictionary(locale);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    queuesApi
      .resolveQrToken(token)
      .then((queue) => router.replace(`/${locale}/join/${queue.id}`))
      .catch(() => setError('This QR code is invalid or has expired.'));
  }, [token]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-3 px-5 text-center">
      {error ? (
        <p className="text-sm text-red">{error}</p>
      ) : (
        <>
          <Spinner />
          <p className="text-sm text-slateSub">{t(dict, 'common.loading')}</p>
        </>
      )}
    </main>
  );
}
