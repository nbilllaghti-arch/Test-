import Link from 'next/link';
import { getDictionary, Locale, t } from '../../../lib/i18n/config';
import { LoginForm } from '../../../components/auth/LoginForm';
import { Card } from '../../../components/ui/Card';

export default function LoginPage({ params }: { params: { locale: Locale } }) {
  const dict = getDictionary(params.locale);
  return (
    <main className="flex min-h-screen items-center justify-center px-5">
      <Card className="w-full max-w-sm p-6">
        <h1 className="mb-5 text-xl font-semibold">{t(dict, 'auth.login')}</h1>
        <LoginForm />
        <p className="mt-4 text-center text-xs text-slateSub">
          {t(dict, 'auth.noAccount')}{' '}
          <Link href={`/${params.locale}/register`} className="text-amber hover:underline">
            {t(dict, 'auth.register')}
          </Link>
        </p>
      </Card>
    </main>
  );
}
