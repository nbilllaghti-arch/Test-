'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { useAuth } from '../../../../lib/auth/AuthContext';
import { organizationsApi } from '../../../../lib/api/organizations';
import { Organization } from '@/types';
import { AdminTopbar } from '../../../../components/layout/AdminTopbar';
import { Card } from '../../../../components/ui/Card';
import { Input } from '../../../../components/ui/Input';
import { Button } from '../../../../components/ui/Button';
import { Spinner } from '../../../../components/ui/Spinner';

export default function OrganizationsPage() {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);
  const { user } = useAuth();

  const [org, setOrg] = useState<Organization | null>(null);
  const [name, setName] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!user?.organizationId) return;
    organizationsApi.get(user.organizationId).then((o) => {
      setOrg(o);
      setName(o.name);
    });
  }, [user]);

  const handleSave = async () => {
    if (!org) return;
    setSaving(true);
    setSaved(false);
    try {
      const updated = await organizationsApi.update(org.id, { name });
      setOrg(updated);
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <AdminTopbar dict={dict} title={t(dict, 'admin.organizations')} />
      <div className="max-w-lg p-6">
        {!org ? (
          <div className="flex justify-center py-16">
            <Spinner />
          </div>
        ) : (
          <Card className="p-5">
            <label className="mb-1 block text-xs text-slateSub">{t(dict, 'settings.organizationName')}</label>
            <Input value={name} onChange={(e) => setName(e.target.value)} className="mb-4" />
            <div className="mb-4 grid grid-cols-2 gap-3 text-xs text-slateSub">
              <div>
                <div className="mb-1">Branches</div>
                <div className="font-mono text-base text-ink dark:text-paper">{org.branches?.length ?? 0}</div>
              </div>
              <div>
                <div className="mb-1">Status</div>
                <div className="font-mono text-base text-ink dark:text-paper">{org.isActive ? 'Active' : 'Inactive'}</div>
              </div>
            </div>
            <Button onClick={handleSave} disabled={saving}>
              {t(dict, 'common.save')}
            </Button>
            {saved && <span className="ms-3 text-xs text-teal">{t(dict, 'settings.saved')}</span>}
          </Card>
        )}
      </div>
    </>
  );
}
