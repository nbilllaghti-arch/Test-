'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { Plus } from 'lucide-react';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { useAuth } from '../../../../lib/auth/AuthContext';
import { staffApi, StaffMember } from '../../../../lib/api/staff';
import { branchesApi } from '../../../../lib/api/branches';
import { queuesApi } from '../../../../lib/api/queues';
import { Branch, Queue } from '@/types';
import { AdminTopbar } from '../../../../components/layout/AdminTopbar';
import { Card } from '../../../../components/ui/Card';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';
import { Button } from '../../../../components/ui/Button';
import { Modal } from '../../../../components/ui/Modal';
import { Badge } from '../../../../components/ui/Badge';
import { Spinner } from '../../../../components/ui/Spinner';

export default function EmployeesPage() {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);
  const { user } = useAuth();

  const [staff, setStaff] = useState<StaffMember[] | null>(null);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [queues, setQueues] = useState<Queue[]>([]);
  const [modalOpen, setModalOpen] = useState(false);

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'branch_admin' | 'employee' | 'reception'>('employee');
  const [branchId, setBranchId] = useState('');
  const [assignQueueId, setAssignQueueId] = useState('');
  const [creating, setCreating] = useState(false);

  const load = async () => {
    if (!user?.organizationId) return;
    const [staffList, branchList] = await Promise.all([staffApi.list(user.organizationId), branchesApi.list(user.organizationId)]);
    setStaff(staffList);
    setBranches(branchList);
    if (branchList[0]) setBranchId(branchList[0].id);
    const allQueues: Queue[] = [];
    for (const b of branchList) allQueues.push(...(await queuesApi.listForBranch(b.id)));
    setQueues(allQueues);
    if (allQueues[0]) setAssignQueueId(allQueues[0].id);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleCreate = async () => {
    if (!user?.organizationId) return;
    setCreating(true);
    try {
      const created = await staffApi.create(user.organizationId, { role, fullName, email, password, branchId });
      if (assignQueueId) await queuesApi.assignEmployee(assignQueueId, created.id);
      setModalOpen(false);
      setFullName('');
      setEmail('');
      setPassword('');
      await load();
    } finally {
      setCreating(false);
    }
  };

  const branchName = (id: string | null) => branches.find((b) => b.id === id)?.name ?? '—';

  return (
    <>
      <AdminTopbar dict={dict} title={t(dict, 'admin.employees')} />
      <div className="p-6">
        <div className="mb-4 flex justify-end">
          <Button onClick={() => setModalOpen(true)}>
            <Plus className="h-4 w-4" /> Invite staff
          </Button>
        </div>

        {!staff ? (
          <div className="flex justify-center py-16">
            <Spinner />
          </div>
        ) : (
          <Card className="overflow-hidden">
            {staff.length === 0 ? (
              <div className="px-4 py-8 text-center text-sm text-slateSub">No staff accounts yet.</div>
            ) : (
              <ul>
                {staff.map((s) => (
                  <li
                    key={s.id}
                    className="flex items-center justify-between border-b border-paperBorder px-4 py-3 last:border-0 dark:border-inkBorder"
                  >
                    <div>
                      <div className="text-sm font-medium">{s.fullName}</div>
                      <div className="text-xs text-slateSub">
                        {s.email} · {branchName(s.branchId)}
                      </div>
                    </div>
                    <Badge status="active">{s.role.replace('_', ' ')}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Invite staff">
        <div className="space-y-3">
          <Input placeholder="Full name" value={fullName} onChange={(e) => setFullName(e.target.value)} />
          <Input placeholder="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input placeholder="Temporary password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <Select value={role} onChange={(e) => setRole(e.target.value as typeof role)}>
            <option value="employee">Employee</option>
            <option value="reception">Reception</option>
            <option value="branch_admin">Branch admin</option>
          </Select>
          <Select value={branchId} onChange={(e) => setBranchId(e.target.value)}>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </Select>
          <div>
            <label className="mb-1 block text-xs text-slateSub">Assign to queue (optional)</label>
            <Select value={assignQueueId} onChange={(e) => setAssignQueueId(e.target.value)}>
              <option value="">None</option>
              {queues.map((q) => (
                <option key={q.id} value={q.id}>
                  {q.name}
                </option>
              ))}
            </Select>
          </div>
          <Button onClick={handleCreate} disabled={creating || !fullName || !email || !password} className="w-full">
            {t(dict, 'common.save')}
          </Button>
        </div>
      </Modal>
    </>
  );
}
