'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { useAuth } from '../../../../lib/auth/AuthContext';
import { branchesApi } from '../../../../lib/api/branches';
import { reportsApi, ReportPeriod } from '../../../../lib/api/reports';
import { Branch, ReportData } from '@/types';
import { AdminTopbar } from '../../../../components/layout/AdminTopbar';
import { Card } from '../../../../components/ui/Card';
import { Select } from '../../../../components/ui/Select';
import { Button } from '../../../../components/ui/Button';
import { Spinner } from '../../../../components/ui/Spinner';

export default function ReportsPage() {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);
  const { user } = useAuth();

  const [branches, setBranches] = useState<Branch[]>([]);
  const [branchId, setBranchId] = useState('');
  const [period, setPeriod] = useState<ReportPeriod>('weekly');
  const [report, setReport] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadBranches() {
      if (user?.organizationId) {
        const list = await branchesApi.list(user.organizationId);
        setBranches(list);
        if (list[0]) setBranchId(list[0].id);
      } else if (user?.branchId) {
        const b = await branchesApi.get(user.branchId);
        setBranches([b]);
        setBranchId(b.id);
      }
    }
    loadBranches();
  }, [user]);

  useEffect(() => {
    if (!branchId) return;
    setLoading(true);
    reportsApi
      .getJson(branchId, period)
      .then(setReport)
      .finally(() => setLoading(false));
  }, [branchId, period]);

  return (
    <>
      <AdminTopbar dict={dict} title={t(dict, 'admin.reports')} />
      <div className="p-6">
        <div className="mb-5 flex flex-wrap items-center gap-3">
          <Select value={branchId} onChange={(e) => setBranchId(e.target.value)} className="max-w-xs">
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </Select>
          <Select value={period} onChange={(e) => setPeriod(e.target.value as ReportPeriod)} className="max-w-xs">
            <option value="daily">{t(dict, 'reports.daily')}</option>
            <option value="weekly">{t(dict, 'reports.weekly')}</option>
            <option value="monthly">{t(dict, 'reports.monthly')}</option>
            <option value="yearly">{t(dict, 'reports.yearly')}</option>
          </Select>
          <div className="ms-auto flex gap-2">
            <Button variant="secondary" onClick={() => reportsApi.download(branchId, period, 'pdf')}>
              PDF
            </Button>
            <Button variant="secondary" onClick={() => reportsApi.download(branchId, period, 'excel')}>
              Excel
            </Button>
          </div>
        </div>

        {loading || !report ? (
          <div className="flex justify-center py-16">
            <Spinner />
          </div>
        ) : (
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <Stat label={t(dict, 'reports.totalTickets')} value={report.totalTickets} />
              <Stat label={t(dict, 'reports.served')} value={report.servedCount} />
              <Stat label={t(dict, 'reports.cancellationRate')} value={`${(report.cancellationRate * 100).toFixed(0)}%`} />
              <Stat label={t(dict, 'reports.noShowRate')} value={`${(report.noShowRate * 100).toFixed(0)}%`} />
            </div>

            <Card className="p-4">
              <div className="mb-3 text-sm font-medium">{t(dict, 'reports.peakHours')}</div>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={report.peakHours.map((p) => ({ hour: `${p.hour}:00`, count: p.count }))}>
                    <XAxis dataKey="hour" fontSize={12} stroke="currentColor" />
                    <YAxis fontSize={12} stroke="currentColor" allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#FFB020" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card className="overflow-hidden">
              <div className="border-b border-paperBorder px-4 py-3 text-sm font-medium dark:border-inkBorder">
                {t(dict, 'reports.employeePerformance')}
              </div>
              {report.employeePerformance.length === 0 ? (
                <div className="px-4 py-6 text-center text-sm text-slateSub">No completed tickets in this period yet.</div>
              ) : (
                <ul>
                  {report.employeePerformance.map((e) => (
                    <li
                      key={e.employeeName}
                      className="flex items-center justify-between border-b border-paperBorder px-4 py-2.5 last:border-0 dark:border-inkBorder"
                    >
                      <span className="text-sm">{e.employeeName}</span>
                      <span className="font-mono text-xs text-slateSub">
                        {e.served} served · {Math.round(e.avgServiceSeconds / 60)}m avg
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        )}
      </div>
    </>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <Card className="px-4 py-3">
      <div className="mb-1 text-xs text-slateSub">{label}</div>
      <div className="font-mono text-xl font-semibold">{value}</div>
    </Card>
  );
}
