'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Plus, ChevronRight } from 'lucide-react';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { useAuth } from '../../../../lib/auth/AuthContext';
import { organizationsApi } from '../../../../lib/api/organizations';
import { branchesApi } from '../../../../lib/api/branches';
import { queuesApi } from '../../../../lib/api/queues';
import { Queue, Branch } from '@/types';
import { AdminTopbar } from '../../../../components/layout/AdminTopbar';
import { Card } from '../../../../components/ui/Card';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';
import { Button } from '../../../../components/ui/Button';
import { Modal } from '../../../../components/ui/Modal';
import { Badge } from '../../../../components/ui/Badge';
import { Spinner } from '../../../../components/ui/Spinner';

export default function QueuesPage() {
  const params = useParams();
  const router = useRouter();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);
  const { user } = useAuth();

  const [branches, setBranches] = useState<Branch[]>([]);
  const [queues, setQueues] = useState<Queue[] | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [branchId, setBranchId] = useState('');
  const [creating, setCreating] = useState(false);

  const load = async () => {
    if (!user) return;
    let bList: Branch[] = [];
    if (user.organizationId) {
      bList = await branchesApi.list(user.organizationId);
    } else if (user.branchId) {
      bList = [await branchesApi.get(user.branchId)];
    }
    setBranches(bList);
    if (bList[0]) setBranchId(bList[0].id);

    const all: Queue[] = [];
    for (const b of bList) {
      all.push(...(await queuesApi.listForBranch(b.id)));
    }
    setQueues(all);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleCreate = async () => {
    if (!branchId) return;
    setCreating(true);
    try {
      await queuesApi.create(branchId, { name, code: code.toUpperCase() });
      setModalOpen(false);
      setName('');
      setCode('');
      await load();
    } finally {
      setCreating(false);
    }
  };

  const branchName = (id: string) => branches.find((b) => b.id === id)?.name ?? id;

  return (
    <>
      <AdminTopbar dict={dict} title={t(dict, 'admin.queues')} />
      <div className="p-6">
        <div className="mb-4 flex justify-end">
          <Button onClick={() => setModalOpen(true)}>
            <Plus className="h-4 w-4" /> {t(dict, 'admin.createQueue')}
          </Button>
        </div>

        {!queues ? (
          <div className="flex justify-center py-16">
            <Spinner />
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {queues.map((q) => (
              <button key={q.id} onClick={() => router.push(`/${locale}/admin/queues/${q.id}`)} className="text-start">
                <Card className="p-4 transition hover:border-amber/50">
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-sm font-medium">{q.name}</span>
                    <ChevronRight className="h-4 w-4 text-slateSub" />
                  </div>
                  <div className="mb-2 text-xs text-slateSub">{branchName(q.branchId)}</div>
                  <div className="flex items-center gap-2">
                    <Badge status={q.isPaused ? 'paused' : 'active'}>{q.isPaused ? 'Paused' : 'Active'}</Badge>
                    <span className="font-mono text-xs text-slateSub">{q.waitingCount ?? 0} waiting</span>
                  </div>
                </Card>
              </button>
            ))}
          </div>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={t(dict, 'admin.createQueue')}>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-xs text-slateSub">Branch</label>
            <Select value={branchId} onChange={(e) => setBranchId(e.target.value)}>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label className="mb-1 block text-xs text-slateSub">Name</label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Cardiology" />
          </div>
          <div>
            <label className="mb-1 block text-xs text-slateSub">Code</label>
            <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="e.g. CD" maxLength={4} />
          </div>
          <Button onClick={handleCreate} disabled={creating || !name || !code || !branchId} className="w-full">
            {t(dict, 'common.save')}
          </Button>
        </div>
      </Modal>
    </>
  );
}
