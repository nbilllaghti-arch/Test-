'use client';

import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getDictionary, t } from '../../../../../lib/i18n/config';
import { queuesApi } from '../../../../../lib/api/queues';
import { ticketsApi } from '../../../../../lib/api/tickets';
import { useQueueRealtime } from '../../../../../lib/realtime/useQueueRealtime';
import { Queue, Ticket } from '@/types';
import { AdminTopbar } from '../../../../../components/layout/AdminTopbar';
import { QueueControlPanel } from '../../../../../components/queues/QueueControlPanel';
import { Spinner } from '../../../../../components/ui/Spinner';

export default function QueueControlPage() {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const queueId = params?.queueId as string;
  const dict = getDictionary(locale);

  const [queue, setQueue] = useState<Queue | null>(null);
  const [waiting, setWaiting] = useState<Ticket[]>([]);
  const [serving, setServing] = useState<Ticket | null>(null);

  const refresh = useCallback(async () => {
    const [q, waitingTickets, servingTickets] = await Promise.all([
      queuesApi.liveStatus(queueId),
      ticketsApi.listForQueue(queueId, 'waiting'),
      ticketsApi.listForQueue(queueId, 'serving'),
    ]);
    setQueue(q);
    setWaiting(waitingTickets);
    setServing(servingTickets[0] ?? null);
  }, [queueId]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useQueueRealtime(queueId, {
    onQueueUpdated: refresh,
    onTicketCalled: refresh,
    onTicketSkipped: refresh,
    onQueuePaused: refresh,
    onQueueResumed: refresh,
  });

  if (!queue) {
    return (
      <>
        <AdminTopbar dict={dict} title={t(dict, 'admin.queues')} />
        <div className="flex justify-center py-16">
          <Spinner />
        </div>
      </>
    );
  }

  return (
    <>
      <AdminTopbar dict={dict} title={queue.name} />
      <div className="p-6">
        <QueueControlPanel queue={queue} servingTicket={serving} waiting={waiting} dict={dict} onChange={refresh} />
      </div>
    </>
  );
}
