'use client';

import { useParams } from 'next/navigation';
import { AuthGuard } from '../../../components/auth/AuthGuard';
import { AdminSidebar } from '../../../components/layout/AdminSidebar';
import { getDictionary } from '../../../lib/i18n/config';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);

  return (
    <AuthGuard allowedRoles={['super_admin', 'org_admin', 'branch_admin', 'reception', 'employee']}>
      <div className="flex min-h-screen">
        <AdminSidebar dict={dict} />
        <div className="flex-1">{children}</div>
      </div>
    </AuthGuard>
  );
}
