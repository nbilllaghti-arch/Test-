'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { Plus } from 'lucide-react';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { useAuth } from '../../../../lib/auth/AuthContext';
import { branchesApi } from '../../../../lib/api/branches';
import { Branch } from '@/types';
import { AdminTopbar } from '../../../../components/layout/AdminTopbar';
import { Card } from '../../../../components/ui/Card';
import { Input } from '../../../../components/ui/Input';
import { Button } from '../../../../components/ui/Button';
import { Modal } from '../../../../components/ui/Modal';
import { Badge } from '../../../../components/ui/Badge';
import { Spinner } from '../../../../components/ui/Spinner';

export default function BranchesPage() {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);
  const { user } = useAuth();

  const [branches, setBranches] = useState<Branch[] | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [creating, setCreating] = useState(false);

  const canManageAll = user?.role === 'super_admin' || user?.role === 'org_admin';

  const load = async () => {
    if (!user) return;
    if (canManageAll && user.organizationId) {
      setBranches(await branchesApi.list(user.organizationId));
    } else if (user.branchId) {
      setBranches([await branchesApi.get(user.branchId)]);
    } else {
      setBranches([]);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleCreate = async () => {
    if (!user?.organizationId) return;
    setCreating(true);
    try {
      await branchesApi.create(user.organizationId, { name, address: address || undefined });
      setModalOpen(false);
      setName('');
      setAddress('');
      await load();
    } finally {
      setCreating(false);
    }
  };

  return (
    <>
      <AdminTopbar dict={dict} title={t(dict, 'admin.branches')} />
      <div className="p-6">
        {canManageAll && (
          <div className="mb-4 flex justify-end">
            <Button onClick={() => setModalOpen(true)}>
              <Plus className="h-4 w-4" /> {t(dict, 'admin.createBranch')}
            </Button>
          </div>
        )}

        {!branches ? (
          <div className="flex justify-center py-16">
            <Spinner />
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {branches.map((b) => (
              <Card key={b.id} className="p-4">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-sm font-medium">{b.name}</span>
                  <Badge status={b.isActive ? 'active' : 'paused'}>{b.isActive ? 'Active' : 'Inactive'}</Badge>
                </div>
                <div className="text-xs text-slateSub">{b.address || 'No address on file'}</div>
                <div className="mt-1 text-xs text-slateSub">Timezone: {b.timezone}</div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={t(dict, 'admin.createBranch')}>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-xs text-slateSub">Name</label>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label className="mb-1 block text-xs text-slateSub">Address</label>
            <Input value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
          <Button onClick={handleCreate} disabled={creating || !name} className="w-full">
            {t(dict, 'common.save')}
          </Button>
        </div>
      </Modal>
    </>
  );
}
