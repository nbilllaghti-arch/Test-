'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { useAuth } from '../../../../lib/auth/AuthContext';
import { organizationsApi } from '../../../../lib/api/organizations';
import { usersApi } from '../../../../lib/api/users';
import { Organization } from '@/types';
import { AdminTopbar } from '../../../../components/layout/AdminTopbar';
import { Card } from '../../../../components/ui/Card';
import { Input } from '../../../../components/ui/Input';
import { Button } from '../../../../components/ui/Button';

export default function SettingsPage() {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);
  const { user } = useAuth();

  const [org, setOrg] = useState<Organization | null>(null);
  const [logoUrl, setLogoUrl] = useState('');
  const [brandColor, setBrandColor] = useState('#FFB020');
  const [saved, setSaved] = useState(false);
  const canEditBranding = user?.role === 'super_admin' || user?.role === 'org_admin';

  useEffect(() => {
    if (!user?.organizationId) return;
    organizationsApi.get(user.organizationId).then((o) => {
      setOrg(o);
      setLogoUrl(o.logoUrl ?? '');
      setBrandColor(o.brandColor ?? '#FFB020');
    });
  }, [user]);

  const saveBranding = async () => {
    if (!org) return;
    setSaved(false);
    await organizationsApi.update(org.id, { logoUrl, brandColor });
    setSaved(true);
  };

  const updatePreference = async (data: { language?: string; darkMode?: boolean }) => {
    await usersApi.updatePreferences(data);
  };

  return (
    <>
      <AdminTopbar dict={dict} title={t(dict, 'admin.settings')} />
      <div className="max-w-lg space-y-5 p-6">
        {canEditBranding && (
          <Card className="p-5">
            <h2 className="mb-4 text-sm font-medium">{t(dict, 'settings.branding')}</h2>
            <label className="mb-1 block text-xs text-slateSub">{t(dict, 'settings.logo')}</label>
            <Input value={logoUrl} onChange={(e) => setLogoUrl(e.target.value)} placeholder="https://…" className="mb-4" />
            <label className="mb-1 block text-xs text-slateSub">{t(dict, 'settings.brandColor')}</label>
            <div className="mb-4 flex items-center gap-2">
              <input
                type="color"
                value={brandColor}
                onChange={(e) => setBrandColor(e.target.value)}
                className="h-9 w-9 rounded border border-paperBorder bg-transparent dark:border-inkBorder"
              />
              <Input value={brandColor} onChange={(e) => setBrandColor(e.target.value)} />
            </div>
            <Button onClick={saveBranding}>{t(dict, 'common.save')}</Button>
            {saved && <span className="ms-3 text-xs text-teal">{t(dict, 'settings.saved')}</span>}
          </Card>
        )}

        <Card className="p-5">
          <h2 className="mb-4 text-sm font-medium">Personal preferences</h2>
          <p className="mb-3 text-xs text-slateSub">
            Language and dark/light mode are controlled from the switches in the top bar and saved automatically to your account.
          </p>
          <Button
            variant="secondary"
            onClick={() => updatePreference({ language: locale, darkMode: document.documentElement.classList.contains('dark') })}
          >
            Sync current preferences to account
          </Button>
        </Card>
      </div>
    </>
  );
}
