'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { useAuth } from '../../../../lib/auth/AuthContext';
import { organizationsApi } from '../../../../lib/api/organizations';
import { branchesApi } from '../../../../lib/api/branches';
import { queuesApi } from '../../../../lib/api/queues';
import { Queue } from '@/types';
import { AdminTopbar } from '../../../../components/layout/AdminTopbar';
import { Card } from '../../../../components/ui/Card';
import { Badge } from '../../../../components/ui/Badge';
import { Spinner } from '../../../../components/ui/Spinner';

export default function DashboardPage() {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);
  const { user } = useAuth();

  const [queues, setQueues] = useState<Queue[] | null>(null);
  const [branchNames, setBranchNames] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!user) return;

    async function load() {
      if (user!.organizationId) {
        const org = await organizationsApi.get(user!.organizationId!);
        const branches = org.branches ?? [];
        const names: Record<string, string> = {};
        const all: Queue[] = [];
        for (const branch of branches) {
          names[branch.id] = branch.name;
          const branchQueues = await queuesApi.listForBranch(branch.id);
          all.push(...branchQueues);
        }
        setBranchNames(names);
        setQueues(all);
      } else if (user!.branchId) {
        const branch = await branchesApi.get(user!.branchId);
        setBranchNames({ [branch.id]: branch.name });
        setQueues(await queuesApi.listForBranch(branch.id));
      } else {
        setQueues([]);
      }
    }
    load();
  }, [user]);

  if (!queues) {
    return (
      <>
        <AdminTopbar dict={dict} title={t(dict, 'admin.dashboard')} />
        <div className="flex justify-center py-16">
          <Spinner />
        </div>
      </>
    );
  }

  const active = queues.filter((q) => !q.isPaused);
  const paused = queues.filter((q) => q.isPaused);
  const totalWaiting = queues.reduce((sum, q) => sum + (q.waitingCount ?? 0), 0);
  const totalServedToday = queues.reduce((sum, q) => sum + (q.servedToday ?? 0), 0);

  return (
    <>
      <AdminTopbar dict={dict} title={t(dict, 'admin.dashboard')} />
      <div className="p-6">
        <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
          <Stat label={t(dict, 'admin.activeQueues')} value={active.length} />
          <Stat label={t(dict, 'admin.pausedQueues')} value={paused.length} />
          <Stat label="Waiting now" value={totalWaiting} />
          <Stat label={t(dict, 'admin.servedToday')} value={totalServedToday} />
        </div>

        <Card className="overflow-hidden">
          <div className="border-b border-paperBorder px-4 py-3 text-sm font-medium dark:border-inkBorder">
            {t(dict, 'admin.queues')}
          </div>
          {queues.length === 0 ? (
            <div className="px-4 py-8 text-center text-sm text-slateSub">No queues yet — create a branch and a queue to get started.</div>
          ) : (
            <ul>
              {queues.map((q) => (
                <li
                  key={q.id}
                  className="flex items-center justify-between border-b border-paperBorder px-4 py-3 last:border-0 dark:border-inkBorder"
                >
                  <div>
                    <div className="text-sm font-medium">{q.name}</div>
                    <div className="text-xs text-slateSub">{branchNames[q.branchId] ?? q.branchId}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-slateSub">{q.waitingCount ?? 0} waiting</span>
                    <Badge status={q.isPaused ? 'paused' : 'active'}>{q.isPaused ? 'Paused' : 'Active'}</Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <Card className="px-4 py-3">
      <div className="mb-1 text-xs text-slateSub">{label}</div>
      <div className="font-mono text-xl font-semibold">{value}</div>
    </Card>
  );
}
