import { ThemeProvider } from '../../lib/theme/ThemeProvider';
import { AuthProvider } from '../../lib/auth/AuthContext';
import { isRtl, Locale, locales } from '../../lib/i18n/config';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: Locale };
}) {
  const dir = isRtl(params.locale) ? 'rtl' : 'ltr';

  return (
    <body dir={dir} lang={params.locale} className="min-h-screen font-sans antialiased">
      <ThemeProvider>
        <AuthProvider>{children}</AuthProvider>
      </ThemeProvider>
    </body>
  );
}
