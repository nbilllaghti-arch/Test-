'use client';

import { useCallback, useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getDictionary } from '../../../../lib/i18n/config';
import { ticketsApi } from '../../../../lib/api/tickets';
import { queuesApi } from '../../../../lib/api/queues';
import { useQueueRealtime } from '../../../../lib/realtime/useQueueRealtime';
import { Ticket, Queue } from '@/types';
import { TicketStub } from '../../../../components/tickets/TicketStub';
import { Spinner } from '../../../../components/ui/Spinner';

export default function TicketPage() {
  const params = useParams();
  const router = useRouter();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const ticketId = params?.ticketId as string;
  const dict = getDictionary(locale);

  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [queue, setQueue] = useState<Queue | null>(null);

  const refresh = useCallback(async () => {
    const t = await ticketsApi.getStatus(ticketId);
    setTicket(t);
    const q = await queuesApi.liveStatus(t.queueId);
    setQueue(q);
  }, [ticketId]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useQueueRealtime(queue?.id ?? null, {
    onQueueUpdated: () => refresh(),
    onTicketCalled: (p) => {
      if (p.ticketId === ticketId) refresh();
    },
    onTicketEtaChanged: (p) => {
      if (p.ticketId === ticketId) refresh();
    },
    onTicketSkipped: (p) => {
      if (p.ticketId === ticketId) refresh();
    },
  });

  // Fallback poll every 10s in case the socket connection drops.
  useEffect(() => {
    const interval = setInterval(refresh, 10_000);
    return () => clearInterval(interval);
  }, [refresh]);

  const handleCancel = async () => {
    await ticketsApi.cancel(ticketId);
    refresh();
  };

  if (!ticket || !queue) {
    return (
      <main className="flex min-h-screen items-center justify-center">
        <Spinner />
      </main>
    );
  }

  const label = `${queue.code}-${String(ticket.ticketNumber).padStart(3, '0')}`;

  return (
    <main className="mx-auto max-w-md px-5 py-10">
      <TicketStub
        ticket={ticket}
        queueLabel={label}
        queueName={queue.name}
        nowServing={queue.nowServing ?? 0}
        dict={dict}
        onCancel={handleCancel}
        onRejoin={() => router.push(`/${locale}/join`)}
      />
    </main>
  );
}
