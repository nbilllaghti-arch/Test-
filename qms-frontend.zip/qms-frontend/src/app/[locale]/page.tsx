import Link from 'next/link';
import { getDictionary, Locale, t } from '../../lib/i18n/config';
import { Button } from '../../components/ui/Button';

export default function LandingPage({ params }: { params: { locale: Locale } }) {
  const dict = getDictionary(params.locale);

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-8 px-5 text-center">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">{t(dict, 'common.appName')}</h1>
        <p className="mt-2 max-w-sm text-sm text-slateSub">{t(dict, 'join.subtitle')}</p>
      </div>
      <div className="flex w-full max-w-xs flex-col gap-3">
        <Link href={`/${params.locale}/join`}>
          <Button className="w-full">{t(dict, 'join.joinQueue')}</Button>
        </Link>
        <Link href={`/${params.locale}/login`}>
          <Button variant="secondary" className="w-full">
            {t(dict, 'auth.login')}
          </Button>
        </Link>
      </div>
    </main>
  );
}
