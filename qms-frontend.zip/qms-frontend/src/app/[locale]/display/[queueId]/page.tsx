'use client';

import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getDictionary, t } from '../../../../lib/i18n/config';
import { queuesApi } from '../../../../lib/api/queues';
import { useQueueRealtime } from '../../../../lib/realtime/useQueueRealtime';
import { Queue } from '@/types';
import { FlapNumber } from '../../../../components/ui/FlapNumber';
import { Spinner } from '../../../../components/ui/Spinner';

export default function DisplayPage() {
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const queueId = params?.queueId as string;
  const dict = getDictionary(locale);

  const [queue, setQueue] = useState<Queue | null>(null);

  const refresh = useCallback(() => {
    queuesApi.display(queueId).then(setQueue);
  }, [queueId]);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 15_000);
    return () => clearInterval(interval);
  }, [refresh]);

  useQueueRealtime(queueId, {
    onQueueUpdated: refresh,
    onTicketCalled: refresh,
    onQueuePaused: refresh,
    onQueueResumed: refresh,
  });

  if (!queue) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-ink">
        <Spinner className="text-paper" />
      </main>
    );
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 bg-ink px-6 text-paper">
      <div className="text-lg uppercase tracking-widest text-slateSub">{queue.name}</div>
      <div>
        <div className="mb-2 text-center text-sm text-slateSub">{t(dict, 'display.nowServing')}</div>
        <FlapNumber text={String(queue.nowServing ?? 0).padStart(3, '0')} size="text-8xl" />
      </div>
      {queue.isPaused && <div className="rounded-full bg-red/20 px-4 py-1.5 text-sm text-red">Queue paused</div>}
      <div className="text-sm text-slateSub">
        {queue.waitingCount ?? 0} waiting · code {queue.code}
      </div>
    </main>
  );
}
