import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Waitline — Queue Management System',
  description: 'Join queues remotely or by QR code, and manage them in real time.',
  manifest: '/manifest.json',
};

export const viewport = {
  themeColor: '#12172B',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html suppressHydrationWarning>{children}</html>;
}
