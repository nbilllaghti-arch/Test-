import { InputHTMLAttributes, forwardRef } from 'react';

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(function Input(
  { className = '', ...props },
  ref,
) {
  return (
    <input
      ref={ref}
      className={`w-full rounded-xl border border-paperBorder bg-transparent px-3.5 py-2.5 text-sm outline-none transition focus:border-amber dark:border-inkBorder ${className}`}
      {...props}
    />
  );
});
