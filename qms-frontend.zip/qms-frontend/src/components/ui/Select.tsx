import { SelectHTMLAttributes, forwardRef } from 'react';

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement>>(function Select(
  { className = '', children, ...props },
  ref,
) {
  return (
    <select
      ref={ref}
      className={`w-full rounded-xl border border-paperBorder bg-transparent px-3.5 py-2.5 text-sm outline-none transition focus:border-amber dark:border-inkBorder ${className}`}
      {...props}
    >
      {children}
    </select>
  );
});
