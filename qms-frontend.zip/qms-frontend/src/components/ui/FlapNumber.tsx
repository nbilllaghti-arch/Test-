'use client';

import { useEffect, useRef, useState } from 'react';

function FlapDigit({ char }: { char: string }) {
  const [display, setDisplay] = useState(char);
  const [flipping, setFlipping] = useState(false);
  const prevChar = useRef(char);

  useEffect(() => {
    if (prevChar.current !== char) {
      setFlipping(true);
      const t = setTimeout(() => {
        setDisplay(char);
        setFlipping(false);
      }, 160);
      prevChar.current = char;
      return () => clearTimeout(t);
    }
  }, [char]);

  return (
    <span className="relative inline-block h-[1em] w-[0.62em] overflow-hidden align-top">
      <span
        className={`absolute inset-0 flex items-center justify-center transition-transform duration-150 ${
          flipping ? '-translate-y-2 opacity-0' : 'translate-y-0 opacity-100'
        }`}
      >
        {display}
      </span>
    </span>
  );
}

export function FlapNumber({ text, size = 'text-6xl' }: { text: string; size?: string }) {
  return (
    <div
      className={`inline-flex rounded-lg border border-inkBorder bg-[#0B0F20] px-5 py-3 font-mono tracking-widest text-amber ${size}`}
      style={{ fontVariantNumeric: 'tabular-nums' }}
    >
      {text.split('').map((c, i) => (
        <FlapDigit key={i} char={c} />
      ))}
    </div>
  );
}
