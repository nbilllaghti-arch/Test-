import { ButtonHTMLAttributes, forwardRef } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
}

const VARIANT_CLASSES: Record<Variant, string> = {
  primary: 'bg-amber text-ink font-medium hover:brightness-95 disabled:opacity-40',
  secondary:
    'border border-paperBorder dark:border-inkBorder text-ink dark:text-paper hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40',
  ghost: 'text-slateSub hover:text-ink dark:hover:text-paper disabled:opacity-40',
  danger: 'border border-red/40 text-red hover:bg-red/10 disabled:opacity-40',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', className = '', ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      className={`inline-flex items-center justify-center gap-1.5 rounded-xl px-4 py-2.5 text-sm transition ${VARIANT_CLASSES[variant]} ${className}`}
      {...props}
    />
  );
});
