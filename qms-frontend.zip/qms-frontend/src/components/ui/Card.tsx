import { HTMLAttributes } from 'react';

export function Card({ className = '', ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={`rounded-2xl border border-paperBorder bg-paperPanel dark:border-inkBorder dark:bg-inkPanel ${className}`}
      {...props}
    />
  );
}
