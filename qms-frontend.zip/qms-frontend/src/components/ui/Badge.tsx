const COLORS: Record<string, string> = {
  waiting: 'bg-slateSub/15 text-slateSub',
  serving: 'bg-amber/20 text-amber',
  done: 'bg-teal/15 text-teal',
  skipped: 'bg-red/15 text-red',
  cancelled: 'bg-red/15 text-red',
  active: 'bg-teal/15 text-teal',
  paused: 'bg-red/15 text-red',
};

export function Badge({ status, children }: { status: string; children: React.ReactNode }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${COLORS[status] ?? 'bg-slateSub/15 text-slateSub'}`}>
      {children}
    </span>
  );
}
