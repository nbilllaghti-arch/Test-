'use client';

import { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Pause, Play, SkipForward, CheckCircle2, ChevronRight, QrCode, Users } from 'lucide-react';
import { Queue, Ticket } from '@/types';
import { Dictionary, t } from '../../lib/i18n/config';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { FlapNumber } from '../ui/FlapNumber';
import { queuesApi } from '../../lib/api/queues';
import { ticketsApi } from '../../lib/api/tickets';

export function QueueControlPanel({
  queue,
  servingTicket,
  waiting,
  dict,
  onChange,
}: {
  queue: Queue;
  servingTicket: Ticket | null;
  waiting: Ticket[];
  dict: Dictionary;
  onChange: () => void;
}) {
  const [qrPayload, setQrPayload] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true);
    try {
      await fn();
      onChange();
    } finally {
      setBusy(false);
    }
  };

  const generateQr = async () => {
    const res = await queuesApi.generateQrToken(queue.id);
    setQrPayload(res.qrPayload);
  };

  return (
    <div className="space-y-5">
      <Card className="flex flex-col items-center justify-between gap-6 p-6 md:flex-row md:items-start">
        <div>
          <div className="mb-2 text-xs uppercase tracking-wide text-slateSub">{t(dict, 'ticket.nowServing')}</div>
          <FlapNumber text={String(queue.nowServing ?? 0).padStart(3, '0')} />
        </div>
        <div className="flex flex-col gap-2">
          <Button
            disabled={busy || !!servingTicket || waiting.length === 0}
            onClick={() => run(() => ticketsApi.callNext(queue.id))}
          >
            {t(dict, 'admin.callNext')} <ChevronRight className="h-4 w-4" />
          </Button>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              disabled={busy || !servingTicket}
              onClick={() => servingTicket && run(() => ticketsApi.complete(servingTicket.id))}
              className="flex-1"
            >
              <CheckCircle2 className="h-3.5 w-3.5" /> {t(dict, 'admin.completeAction')}
            </Button>
            <Button
              variant="secondary"
              disabled={busy || !servingTicket}
              onClick={() => servingTicket && run(() => ticketsApi.skip(servingTicket.id))}
              className="flex-1"
            >
              <SkipForward className="h-3.5 w-3.5" /> {t(dict, 'admin.skip')}
            </Button>
          </div>
          <Button
            variant="secondary"
            disabled={busy}
            onClick={() => run(() => (queue.isPaused ? queuesApi.resume(queue.id) : queuesApi.pause(queue.id)))}
          >
            {queue.isPaused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
            {queue.isPaused ? t(dict, 'admin.resumeQueue') : t(dict, 'admin.pauseQueue')}
          </Button>
        </div>
      </Card>

      <Card className="p-4">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-sm font-medium">{t(dict, 'admin.generateQr')}</span>
          <Button variant="secondary" onClick={generateQr}>
            <QrCode className="h-3.5 w-3.5" /> {t(dict, 'admin.generateQr')}
          </Button>
        </div>
        {qrPayload && (
          <div className="flex flex-col items-center gap-3 rounded-lg bg-black/5 p-4 dark:bg-white/5">
            <div className="rounded-lg bg-white p-3">
              <QRCodeSVG value={qrPayload} size={160} />
            </div>
            <div className="break-all font-mono text-xs text-slateSub">{qrPayload}</div>
            <div className="text-center text-xs text-slateSub">Print or display this on a screen at the queue entrance.</div>
          </div>
        )}
      </Card>

      <Card className="overflow-hidden">
        <div className="flex items-center gap-2 border-b border-paperBorder px-4 py-3 text-sm font-medium dark:border-inkBorder">
          <Users className="h-4 w-4" /> {t(dict, 'admin.waitingList')}
        </div>
        {waiting.length === 0 ? (
          <div className="px-4 py-6 text-center text-sm text-slateSub">No customers waiting</div>
        ) : (
          <ul>
            {waiting.map((ticket) => (
              <li
                key={ticket.id}
                className="flex items-center justify-between border-b border-paperBorder px-4 py-2.5 last:border-0 dark:border-inkBorder"
              >
                <span className="font-mono text-sm">
                  {queue.code}-{String(ticket.ticketNumber).padStart(3, '0')}
                  {ticket.isPriority && <span className="ms-2 text-xs text-amber">priority</span>}
                </span>
                <div className="flex items-center gap-3 text-xs text-slateSub">
                  <span>{new Date(ticket.joinedAt).toLocaleTimeString()}</span>
                  {!ticket.isPriority && (
                    <button onClick={() => run(() => ticketsApi.setPriority(ticket.id))} className="text-amber hover:underline">
                      {t(dict, 'admin.priority')}
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
