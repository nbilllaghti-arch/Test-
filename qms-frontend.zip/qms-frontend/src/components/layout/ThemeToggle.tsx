'use client';

import { Moon, Sun } from 'lucide-react';
import { useTheme } from '../../lib/theme/ThemeProvider';

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  return (
    <button
      onClick={toggleTheme}
      aria-label="Toggle theme"
      className="rounded-full border border-paperBorder p-2 hover:opacity-80 dark:border-inkBorder"
    >
      {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </button>
  );
}
