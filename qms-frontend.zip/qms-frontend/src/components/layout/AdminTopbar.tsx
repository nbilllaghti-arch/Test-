'use client';

import { useParams, useRouter } from 'next/navigation';
import { LogOut, Menu } from 'lucide-react';
import { LanguageSwitcher } from './LanguageSwitcher';
import { ThemeToggle } from './ThemeToggle';
import { useAuth } from '../../lib/auth/AuthContext';
import { Dictionary, t } from '../../lib/i18n/config';

export function AdminTopbar({ dict, title }: { dict: Dictionary; title: string }) {
  const { logout } = useAuth();
  const router = useRouter();
  const params = useParams();
  const locale = (params?.locale as string) ?? 'en';

  const handleLogout = () => {
    logout();
    router.push(`/${locale}/login`);
  };

  return (
    <header className="flex items-center justify-between border-b border-paperBorder px-5 py-4 dark:border-inkBorder">
      <div className="flex items-center gap-2">
        <Menu className="h-5 w-5 md:hidden" />
        <h1 className="text-lg font-semibold">{title}</h1>
      </div>
      <div className="flex items-center gap-2">
        <LanguageSwitcher />
        <ThemeToggle />
        <button
          onClick={handleLogout}
          className="flex items-center gap-1.5 rounded-full border border-paperBorder px-3 py-1.5 text-xs text-slateSub hover:text-ink dark:border-inkBorder dark:hover:text-paper"
        >
          <LogOut className="h-3.5 w-3.5" /> {t(dict, 'common.logout')}
        </button>
      </div>
    </header>
  );
}
