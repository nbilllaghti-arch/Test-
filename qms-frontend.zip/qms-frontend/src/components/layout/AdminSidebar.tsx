'use client';

import Link from 'next/link';
import { usePathname, useParams } from 'next/navigation';
import {
  LayoutDashboard,
  Building2,
  GitBranch,
  ListOrdered,
  Users,
  FileBarChart,
  Settings,
} from 'lucide-react';
import { Dictionary, t } from '../../lib/i18n/config';

const ITEMS = (locale: string) => [
  { href: `/${locale}/admin/dashboard`, key: 'admin.dashboard', icon: LayoutDashboard },
  { href: `/${locale}/admin/organizations`, key: 'admin.organizations', icon: Building2 },
  { href: `/${locale}/admin/branches`, key: 'admin.branches', icon: GitBranch },
  { href: `/${locale}/admin/queues`, key: 'admin.queues', icon: ListOrdered },
  { href: `/${locale}/admin/employees`, key: 'admin.employees', icon: Users },
  { href: `/${locale}/admin/reports`, key: 'admin.reports', icon: FileBarChart },
  { href: `/${locale}/admin/settings`, key: 'admin.settings', icon: Settings },
];

export function AdminSidebar({ dict }: { dict: Dictionary }) {
  const pathname = usePathname();
  const params = useParams();
  const locale = (params?.locale as string) ?? 'en';

  return (
    <aside className="hidden w-60 shrink-0 border-e border-paperBorder p-4 dark:border-inkBorder md:block">
      <div className="mb-6 px-2 text-lg font-semibold tracking-tight">{t(dict, 'common.appName')}</div>
      <nav className="space-y-1">
        {ITEMS(locale).map((item) => {
          const Icon = item.icon;
          const active = pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm transition ${
                active ? 'bg-amber/15 text-amber font-medium' : 'text-slateSub hover:bg-black/5 dark:hover:bg-white/5'
              }`}
            >
              <Icon className="h-4 w-4" />
              {t(dict, item.key)}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
