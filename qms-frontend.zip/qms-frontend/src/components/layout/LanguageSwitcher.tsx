'use client';

import { useParams, usePathname, useRouter } from 'next/navigation';
import { locales } from '../../lib/i18n/config';

export function LanguageSwitcher() {
  const router = useRouter();
  const pathname = usePathname();
  const params = useParams();
  const currentLocale = (params?.locale as string) ?? 'en';

  const switchTo = (locale: string) => {
    document.cookie = `locale=${locale}; path=/; max-age=31536000`;
    const segments = pathname.split('/');
    segments[1] = locale;
    router.push(segments.join('/'));
  };

  return (
    <div className="flex items-center gap-1 rounded-full border border-paperBorder p-0.5 text-xs dark:border-inkBorder">
      {locales.map((locale) => (
        <button
          key={locale}
          onClick={() => switchTo(locale)}
          className={`rounded-full px-2.5 py-1 transition ${
            currentLocale === locale ? 'bg-amber text-ink font-medium' : 'text-slateSub hover:text-ink dark:hover:text-paper'
          }`}
        >
          {locale.toUpperCase()}
        </button>
      ))}
    </div>
  );
}
