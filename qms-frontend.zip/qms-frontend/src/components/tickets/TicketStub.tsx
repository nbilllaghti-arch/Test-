'use client';

import { useState } from 'react';
import { CheckCircle2, TicketX, X, Clock, Star } from 'lucide-react';
import { Ticket } from '@/types';
import { Dictionary, t } from '../../lib/i18n/config';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { FlapNumber } from '../ui/FlapNumber';
import { ticketsApi } from '../../lib/api/tickets';

export function TicketStub({
  ticket,
  queueLabel,
  queueName,
  nowServing,
  dict,
  onCancel,
  onRejoin,
}: {
  ticket: Ticket;
  queueLabel: string;
  queueName: string;
  nowServing: number;
  dict: Dictionary;
  onCancel: () => void;
  onRejoin: () => void;
}) {
  const [rating, setRating] = useState(0);
  const [ratingSubmitted, setRatingSubmitted] = useState(false);

  const isServing = ticket.status === 'serving';
  const isDone = ticket.status === 'done';
  const isSkipped = ticket.status === 'skipped';
  const isCancelled = ticket.status === 'cancelled';

  const submitRating = async (score: number) => {
    setRating(score);
    await ticketsApi.rate(ticket.id, score);
    setRatingSubmitted(true);
  };

  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between border-b border-dashed border-paperBorder px-5 pb-4 pt-5 dark:border-inkBorder">
        <div>
          <div className="text-xs uppercase tracking-wide text-slateSub">{queueName}</div>
          <div className="font-mono text-xl font-semibold tracking-wide">{queueLabel}</div>
        </div>
        {isDone && <CheckCircle2 className="h-6 w-6 text-teal" />}
        {(isSkipped || isCancelled) && <TicketX className="h-6 w-6 text-red" />}
      </div>

      <div className="px-5 py-6 text-center">
        {isDone ? (
          ratingSubmitted ? (
            <p className="text-sm text-teal">Thanks for your feedback.</p>
          ) : (
            <>
              <p className="mb-3 text-sm">{t(dict, 'ticket.complete')}</p>
              <p className="mb-2 text-xs text-slateSub">{t(dict, 'ticket.rateService')}</p>
              <div className="flex justify-center gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} onClick={() => submitRating(n)} aria-label={`Rate ${n}`}>
                    <Star className={`h-6 w-6 ${n <= rating ? 'fill-amber text-amber' : 'text-slateSub'}`} />
                  </button>
                ))}
              </div>
            </>
          )
        ) : isSkipped ? (
          <p className="text-sm text-red">{t(dict, 'ticket.skipped')}</p>
        ) : isCancelled ? (
          <p className="text-sm text-slateSub">This ticket was cancelled.</p>
        ) : isServing ? (
          <>
            <p className="mb-3 text-sm font-medium text-amber">{t(dict, 'ticket.yourTurn')}</p>
            <FlapNumber text={queueLabel.replace(/\D/g, '')} size="text-4xl" />
          </>
        ) : (
          <>
            <div className="mb-1 text-xs text-slateSub">{t(dict, 'ticket.peopleAhead')}</div>
            <div className="mb-3 font-mono text-4xl font-semibold">{ticket.position ?? 0}</div>
            <div className="flex items-center justify-center gap-1 text-xs text-slateSub">
              <Clock className="h-3.5 w-3.5" />
              {t(dict, 'ticket.estimatedWait')} ~{Math.ceil((ticket.estimatedWaitSeconds ?? 0) / 60)} min
            </div>
          </>
        )}
      </div>

      <div className="flex items-center justify-between border-t border-paperBorder px-5 py-3 dark:border-inkBorder">
        <span className="text-xs text-slateSub">
          {t(dict, 'ticket.nowServing')}: {queueLabel.split('-')[0]}-{String(nowServing).padStart(3, '0')}
        </span>
        {!isDone && !isSkipped && !isCancelled && (
          <button onClick={onCancel} className="flex items-center gap-1 text-xs text-red hover:underline">
            <X className="h-3.5 w-3.5" /> {t(dict, 'ticket.cancel')}
          </button>
        )}
      </div>

      {(isDone || isSkipped || isCancelled) && (
        <div className="border-t border-paperBorder p-4 dark:border-inkBorder">
          <Button onClick={onRejoin} className="w-full">
            {t(dict, 'ticket.rejoin')}
          </Button>
        </div>
      )}
    </Card>
  );
}
