'use client';

import { useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useAuth } from '../../lib/auth/AuthContext';
import { getDictionary, t } from '../../lib/i18n/config';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';

export function RegisterForm() {
  const { register } = useAuth();
  const router = useRouter();
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);

  const [role, setRole] = useState<'org_admin' | 'customer'>('org_admin');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [organizationName, setOrganizationName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await register({ role, fullName, email, password, organizationName: role === 'org_admin' ? organizationName : undefined });
      router.push(role === 'org_admin' ? `/${locale}/admin/dashboard` : `/${locale}/join`);
    } catch {
      setError(t(dict, 'common.error'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <label className="mb-1 block text-xs text-slateSub">Account type</label>
        <Select value={role} onChange={(e) => setRole(e.target.value as 'org_admin' | 'customer')}>
          <option value="org_admin">Organization admin</option>
          <option value="customer">Customer</option>
        </Select>
      </div>
      <div>
        <label className="mb-1 block text-xs text-slateSub">{t(dict, 'auth.fullName')}</label>
        <Input required value={fullName} onChange={(e) => setFullName(e.target.value)} />
      </div>
      {role === 'org_admin' && (
        <div>
          <label className="mb-1 block text-xs text-slateSub">{t(dict, 'auth.organizationName')}</label>
          <Input required value={organizationName} onChange={(e) => setOrganizationName(e.target.value)} />
        </div>
      )}
      <div>
        <label className="mb-1 block text-xs text-slateSub">{t(dict, 'auth.email')}</label>
        <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <label className="mb-1 block text-xs text-slateSub">{t(dict, 'auth.password')}</label>
        <Input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      {error && <p className="text-xs text-red">{error}</p>}
      <Button type="submit" disabled={submitting} className="w-full">
        {t(dict, 'auth.registerCta')}
      </Button>
    </form>
  );
}
