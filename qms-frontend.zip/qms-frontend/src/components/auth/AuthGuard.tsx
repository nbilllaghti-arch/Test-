'use client';

import { useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useAuth } from '../../lib/auth/AuthContext';
import { UserRole } from '@/types';

export function AuthGuard({ children, allowedRoles }: { children: React.ReactNode; allowedRoles?: UserRole[] }) {
  const { user, loading } = useAuth();
  const router = useRouter();
  const params = useParams();
  const locale = params?.locale ?? 'en';

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace(`/${locale}/login`);
      return;
    }
    if (allowedRoles && !allowedRoles.includes(user.role)) {
      router.replace(`/${locale}/join`);
    }
  }, [loading, user, allowedRoles, router, locale]);

  if (loading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-paper dark:bg-ink text-ink dark:text-paper">
        <span className="text-sm text-slateSub">Loading...</span>
      </div>
    );
  }

  return <>{children}</>;
}
