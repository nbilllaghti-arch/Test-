'use client';

import { useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useAuth } from '../../lib/auth/AuthContext';
import { getDictionary, t } from '../../lib/i18n/config';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { ApiError } from '../../lib/api/client';

export function LoginForm() {
  const { login } = useAuth();
  const router = useRouter();
  const params = useParams();
  const locale = (params?.locale as 'en' | 'ar') ?? 'en';
  const dict = getDictionary(locale);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login(email, password);
      router.push(`/${locale}/admin/dashboard`);
    } catch (err) {
      setError(err instanceof ApiError ? t(dict, 'auth.invalidCredentials') : t(dict, 'common.error'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <label className="mb-1 block text-xs text-slateSub">{t(dict, 'auth.email')}</label>
        <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <label className="mb-1 block text-xs text-slateSub">{t(dict, 'auth.password')}</label>
        <Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      {error && <p className="text-xs text-red">{error}</p>}
      <Button type="submit" disabled={submitting} className="w-full">
        {t(dict, 'auth.loginCta')}
      </Button>
    </form>
  );
}
