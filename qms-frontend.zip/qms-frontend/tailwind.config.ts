import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        ink: '#12172B',
        inkPanel: '#171D36',
        inkBorder: '#2A3152',
        paper: '#EFEEE9',
        paperPanel: '#FFFFFF',
        paperBorder: '#DCD9D0',
        amber: '#FFB020',
        teal: '#1F6F5C',
        red: '#C6432F',
        slateSub: '#6B7280',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
    },
  },
  plugins: [],
};

export default config;
